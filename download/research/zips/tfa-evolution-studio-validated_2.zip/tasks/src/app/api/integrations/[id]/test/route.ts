import { NextRequest, NextResponse } from "next/server";
import { testConnector } from "@/lib/integrations/connector-runtime";

export async function POST(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  try {
    const result = await testConnector(id);
    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json({ ok: false, error: String(err), latencyMs: 0 }, { status: 500 });
  }
}
