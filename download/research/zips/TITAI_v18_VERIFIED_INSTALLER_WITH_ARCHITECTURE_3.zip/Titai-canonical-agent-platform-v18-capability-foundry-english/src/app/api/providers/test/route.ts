import { NextResponse } from "next/server";
import { z } from "zod";
import { eq } from "drizzle-orm";
import { auth } from "@/auth";
import { db, schema } from "@/lib/db";
import { decryptSecret } from "@/lib/crypto";
import { gateway } from "@/lib/engine/gateway";
import { DEFAULT_MODELS, KEYLESS_PROVIDERS, PROVIDERS } from "@/lib/constants";
import type { ProviderName } from "@/lib/engine/types";

export const runtime = "nodejs";

const body = z.object({ provider: z.enum(PROVIDERS as [string, ...string[]]) });

export async function POST(req: Request) {
  const session = await auth();
  if (!session?.user?.id) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const parsed = body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "invalid" }, { status: 400 });
  }
  const provider = parsed.data.provider as ProviderName;
  const { checkRateLimit } = await import("@/lib/rate-limit");
  if (!checkRateLimit(`provider-test:${session.user.id}`, { limit: 10, windowMs: 60_000 })) {
    return NextResponse.json({ ok: false, error: "rate_limited" }, { status: 429 });
  }

  if (provider === "simulation") {
    return NextResponse.json({ ok: true });
  }

  const config = db
    .select()
    .from(schema.providerConfigs)
    .where(eq(schema.providerConfigs.userId, session.user.id))
    .all()
    .find((c) => c.provider === provider);

  if (config && !config.enabled) {
    return NextResponse.json({ ok: false, error: "provider_disabled" });
  }

  let apiKey: string | undefined;
  if (config?.apiKeyCiphertext && config.apiKeyIv && config.apiKeyTag) {
    try {
      apiKey = decryptSecret(
        {
          version: config.apiKeyVersion as 1 | 2,
          ciphertext: config.apiKeyCiphertext,
          iv: config.apiKeyIv,
          tag: config.apiKeyTag,
        },
        `${session.user.id}:${parsed.data.provider}`,
      );
    } catch {
      /* ignore */
    }
  }
  if (!apiKey && !KEYLESS_PROVIDERS.includes(provider)) {
    return NextResponse.json({ ok: false, error: "no_key" });
  }

  const result = await gateway.chat({
    provider,
    model: config?.defaultModel || DEFAULT_MODELS[provider],
    messages: [{ role: "user", content: "ping" }],
    stream: false,
    apiKey,
    baseUrl: config?.baseUrl ?? undefined,
    temperature: 0,
  });

  return NextResponse.json({ ok: result.ok, error: result.error });
}
