// test/basic.test.ts — Smoke tests for all 10 strategies — zip-to-pdf-polyglot v9.1.0
//
// Run: npx tsx test/basic.test.ts
//
// Coverage:
//   - listStrategies() returns all 10 strategies
//   - build + verify for all 8 non-passphrase strategies
//   - extract for all extractable non-passphrase strategies
//   - build + extract for both passphrase strategies (encrypted, chacha20-poly1305)
//   - wrong passphrase correctly rejected for encrypted strategies
//   - missing passphrase for encrypted strategies throws (no silent default)
//   - RSA signature verified on extract
//   - verifyPolyglot returns recognized=false for garbage files
//   - verifyPolyglot detects encrypted by marker only (no decryption, no passphrase needed)
//   - full round-trip: original bytes survive extract → rebuild → re-extract

import { readFileSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { buildPolyglot, extractPolyglot, verifyPolyglot, listStrategies } from "../src/index";
import type { StrategyName } from "../src/types";

// ── Correct test ZIP ───────────────────────────────────────────────────────

/** CRC-32 table (IEEE polynomial). */
const CRC_TABLE: number[] = (() => {
  const t: number[] = [];
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(bytes: Uint8Array): number {
  let c = 0xffffffff;
  for (const b of bytes) c = CRC_TABLE[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function writeU16LE(buf: Uint8Array, off: number, v: number) { buf[off] = v & 0xff; buf[off+1] = (v >> 8) & 0xff; }
function writeU32LE(buf: Uint8Array, off: number, v: number) {
  buf[off] = v & 0xff; buf[off+1] = (v >> 8) & 0xff;
  buf[off+2] = (v >> 16) & 0xff; buf[off+3] = (v >>> 24) & 0xff;
}

/**
 * Build a minimal but CORRECT ZIP containing one stored file "hello.txt"
 * with content "Hello, World!\n" and a properly computed CRC-32.
 */
function buildMinimalZip(): Uint8Array {
  const content  = new TextEncoder().encode("Hello, World!\n"); // 14 bytes
  const filename = new TextEncoder().encode("hello.txt");
  const crc      = crc32(content);                             // correct CRC

  // Local file header (30 + filename.length + content.length)
  const lfh = new Uint8Array(30 + filename.length + content.length);
  writeU32LE(lfh, 0,  0x04034b50); // LFH signature
  writeU16LE(lfh, 4,  20);          // version needed
  writeU16LE(lfh, 6,  0);           // flags
  writeU16LE(lfh, 8,  0);           // compression: stored
  writeU16LE(lfh, 10, 0);           // mod time
  writeU16LE(lfh, 12, 0x0021);      // mod date (1980-01-01)
  writeU32LE(lfh, 14, crc);         // CRC-32 (correct)
  writeU32LE(lfh, 18, content.length); // compressed size
  writeU32LE(lfh, 22, content.length); // uncompressed size
  writeU16LE(lfh, 26, filename.length);
  writeU16LE(lfh, 28, 0);           // extra length
  lfh.set(filename, 30);
  lfh.set(content, 30 + filename.length);

  // Central directory entry (46 + filename.length)
  const cd = new Uint8Array(46 + filename.length);
  writeU32LE(cd, 0,  0x02014b50); // CD signature
  writeU16LE(cd, 4,  20);          // version made by
  writeU16LE(cd, 6,  20);          // version needed
  writeU16LE(cd, 8,  0);           // flags
  writeU16LE(cd, 10, 0);           // compression
  writeU16LE(cd, 12, 0);           // mod time
  writeU16LE(cd, 14, 0x0021);      // mod date
  writeU32LE(cd, 16, crc);         // CRC-32 (correct)
  writeU32LE(cd, 20, content.length);
  writeU32LE(cd, 24, content.length);
  writeU16LE(cd, 28, filename.length);
  writeU16LE(cd, 30, 0);           // extra length
  writeU16LE(cd, 32, 0);           // comment length
  writeU16LE(cd, 34, 0);           // disk start
  writeU16LE(cd, 36, 0);           // internal attr
  writeU32LE(cd, 38, 0);           // external attr
  writeU32LE(cd, 42, 0);           // local header offset
  cd.set(filename, 46);

  // End of central directory (22 bytes)
  const eocd = new Uint8Array(22);
  writeU32LE(eocd, 0,  0x06054b50);
  writeU16LE(eocd, 4,  0);          // disk number
  writeU16LE(eocd, 6,  0);          // disk with CD
  writeU16LE(eocd, 8,  1);          // entries on this disk
  writeU16LE(eocd, 10, 1);          // total entries
  writeU32LE(eocd, 12, cd.length);
  writeU32LE(eocd, 16, lfh.length); // CD offset
  writeU16LE(eocd, 20, 0);          // comment length

  const total = new Uint8Array(lfh.length + cd.length + eocd.length);
  total.set(lfh, 0);
  total.set(cd, lfh.length);
  total.set(eocd, lfh.length + cd.length);
  return total;
}

// ── Test runner ────────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void | Promise<void>) {
  try {
    const r = fn();
    if (r instanceof Promise) {
      r.then(() => {
        console.log(`  ✓ ${name}`);
        passed++;
      }).catch((err) => {
        console.log(`  ✗ ${name}: ${err instanceof Error ? err.message : String(err)}`);
        failed++;
      });
    } else {
      console.log(`  ✓ ${name}`);
      passed++;
    }
  } catch (err) {
    console.log(`  ✗ ${name}: ${err instanceof Error ? err.message : String(err)}`);
    failed++;
  }
}

function assert(condition: boolean, message: string) {
  if (!condition) throw new Error(message);
}

function assertThrows(fn: () => unknown, containing: string) {
  try {
    fn();
    throw new Error(`Expected an error containing "${containing}" but none was thrown`);
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    if (!msg.includes(containing)) {
      throw new Error(`Expected error containing "${containing}", got: ${msg}`);
    }
  }
}

// ── Tests ──────────────────────────────────────────────────────────────────

async function main() {
  const zipBuf = buildMinimalZip();
  console.log("\nzip-to-pdf-polyglot v9.1.0 — smoke tests\n");

  // ── Strategy registry ──────────────────────────────────────────────────
  test("listStrategies returns exactly 10 strategies", () => {
    const strategies = listStrategies();
    assert(strategies.length === 10, `Expected 10 strategies, got ${strategies.length}`);
    const names = strategies.map((s) => s.name);
    for (const expected of ["agent-readable", "encrypted", "chacha20-poly1305", "rsa-signed",
      "raw-polyglot-patched", "raw-polyglot-unpatched", "pdf-attachment",
      "xmp-embedded", "portfolio", "raw-polyglot-signed"]) {
      assert(names.includes(expected as StrategyName), `Missing strategy: ${expected}`);
    }
  });

  test("encrypted + chacha20-poly1305 are marked requiresPassphrase=true", () => {
    const strats = listStrategies();
    const enc   = strats.find((s) => s.name === "encrypted");
    const cc    = strats.find((s) => s.name === "chacha20-poly1305");
    assert(enc?.requiresPassphrase === true,  "encrypted should requiresPassphrase");
    assert(cc?.requiresPassphrase  === true,  "chacha20-poly1305 should requiresPassphrase");
    const others = strats.filter((s) => s.name !== "encrypted" && s.name !== "chacha20-poly1305");
    for (const s of others) {
      assert(s.requiresPassphrase === false, `${s.name} should NOT requiresPassphrase`);
    }
  });

  // ── Security: no silent default passphrase ─────────────────────────────
  test("build encrypted without passphrase throws (no silent default)", () => {
    assertThrows(
      () => buildPolyglot(zipBuf, "test.zip", { strategy: "encrypted", embedFont: false, embedDiagram: false }),
      "passphrase"
    );
  });

  test("build chacha20-poly1305 without passphrase throws (no silent default)", () => {
    assertThrows(
      () => buildPolyglot(zipBuf, "test.zip", { strategy: "chacha20-poly1305", embedFont: false, embedDiagram: false }),
      "passphrase"
    );
  });

  // ── Non-passphrase strategies: build + verify + extract ───────────────
  const PLAIN_STRATEGIES: StrategyName[] = [
    "agent-readable",
    "raw-polyglot-patched",
    "raw-polyglot-unpatched",
    "pdf-attachment",
    "xmp-embedded",
    "portfolio",
    "raw-polyglot-signed",
    "rsa-signed",
  ];

  for (const strategy of PLAIN_STRATEGIES) {
    test(`build+verify: ${strategy}`, () => {
      const result = buildPolyglot(zipBuf, "test.zip", {
        strategy,
        embedFont: false,
        embedDiagram: false,
      });
      assert(result.bytes.length > 200, `${strategy}: PDF is too small (${result.bytes.length} bytes)`);
      assert(result.bytes[0] === 0x25 && result.bytes[1] === 0x50, `${strategy}: PDF magic missing`);
      assert(result.entryCount >= 1, `${strategy}: entryCount should be ≥ 1`);
      assert(result.strategy === strategy, `strategy field wrong: ${result.strategy}`);

      const report = verifyPolyglot(result.bytes);
      assert(report.pdfMagic, `${strategy}: verifyPolyglot pdfMagic=false`);
      assert(report.recognized, `${strategy}: verifyPolyglot recognized=false`);
      assert(report.strategy === strategy, `${strategy}: verifyPolyglot.strategy=${report.strategy}`);
    });
  }

  // extract round-trip for all except unpatched (needs tolerant unzip)
  for (const strategy of PLAIN_STRATEGIES.filter((s) => s !== "raw-polyglot-unpatched")) {
    test(`extract round-trip: ${strategy}`, () => {
      const built = buildPolyglot(zipBuf, "test.zip", {
        strategy, embedFont: false, embedDiagram: false,
      });
      const extracted = extractPolyglot(built.bytes, {});
      assert(extracted.entryCount >= 1, `extract ${strategy}: entryCount = 0`);
      assert(extracted.bytes.length > 0, `extract ${strategy}: empty ZIP`);
      assert(extracted.strategy === strategy, `extract ${strategy}: strategy=${extracted.strategy}`);
      assert(extracted.zipSize === extracted.bytes.length, `extract ${strategy}: zipSize mismatch`);
    });
  }

  // ── Passphrase strategies ──────────────────────────────────────────────
  for (const strategy of ["encrypted", "chacha20-poly1305"] as StrategyName[]) {
    test(`build+extract: ${strategy} (correct passphrase)`, () => {
      const pass = "test-passphrase-v9.1-correct";
      const built = buildPolyglot(zipBuf, "test.zip", {
        strategy, passphrase: pass, embedFont: false, embedDiagram: false,
      });
      assert(built.bytes[0] === 0x25, `${strategy}: not a PDF`);

      const extracted = extractPolyglot(built.bytes, { passphrase: pass });
      assert(extracted.entryCount >= 1, `extract ${strategy}: entryCount = 0`);
      assert(extracted.strategy === strategy, `extract strategy mismatch`);
    });

    test(`wrong passphrase rejected: ${strategy}`, () => {
      const built = buildPolyglot(zipBuf, "test.zip", {
        strategy, passphrase: "correct-pass", embedFont: false, embedDiagram: false,
      });
      assertThrows(
        () => extractPolyglot(built.bytes, { passphrase: "wrong-pass" }),
        "authentication failed"
      );
    });

    test(`extract without passphrase skips ${strategy} gracefully`, () => {
      const built = buildPolyglot(zipBuf, "test.zip", {
        strategy, passphrase: "some-pass", embedFont: false, embedDiagram: false,
      });
      // Without passphrase, should skip the encrypted strategy and throw "no matching strategy"
      assertThrows(
        () => extractPolyglot(built.bytes, {}),
        "passphrase"
      );
    });
  }

  // ── verifyPolyglot: encrypted by marker only (no passphrase, no PBKDF2) ─
  test("verifyPolyglot detects encrypted by marker only (no passphrase needed)", () => {
    const built = buildPolyglot(zipBuf, "test.zip", {
      strategy: "encrypted", passphrase: "any-passphrase",
      embedFont: false, embedDiagram: false,
    });
    const report = verifyPolyglot(built.bytes);
    assert(report.recognized, "encrypted PDF should be recognized by verifyPolyglot");
    assert(report.strategy === "encrypted", `strategy=${report.strategy}`);
    // entryCount is null for marker-only detection (no decryption)
    assert(report.entryCount === null, "entryCount should be null for encrypted (no decryption)");
  });

  test("verifyPolyglot detects chacha20-poly1305 by marker only", () => {
    const built = buildPolyglot(zipBuf, "test.zip", {
      strategy: "chacha20-poly1305", passphrase: "any-passphrase",
      embedFont: false, embedDiagram: false,
    });
    const report = verifyPolyglot(built.bytes);
    assert(report.recognized, "chacha20 PDF should be recognized");
    assert(report.strategy === "chacha20-poly1305", `strategy=${report.strategy}`);
    assert(report.entryCount === null, "entryCount should be null");
  });

  // ── RSA signature ──────────────────────────────────────────────────────
  test("rsa-signed: private key returned, signature verified on extract", () => {
    const built = buildPolyglot(zipBuf, "test.zip", {
      strategy: "rsa-signed", embedFont: false, embedDiagram: false,
    });
    assert(built.privateKeyPem !== undefined && built.privateKeyPem.length > 100, "no private key returned");
    assert(built.publicKeyPem  !== undefined && built.publicKeyPem.length  > 100, "no public key returned");

    const extracted = extractPolyglot(built.bytes, {});
    assert(extracted.signatureValid === true, "RSA signature should be VALID");
  });

  // ── unrecognized file ──────────────────────────────────────────────────
  test("verifyPolyglot: garbage PDF prefix → recognized=false", () => {
    const garbage = new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x35, 0x0a]);
    const report = verifyPolyglot(garbage);
    assert(report.pdfMagic === true, "pdfMagic should be true");
    assert(report.recognized === false, "should not recognize minimal garbage");
  });

  test("verifyPolyglot: empty buffer → pdfMagic=false, recognized=false", () => {
    const report = verifyPolyglot(new Uint8Array(0));
    assert(report.pdfMagic === false, "pdfMagic should be false");
    assert(report.recognized === false, "should not recognize empty buffer");
  });

  // ── full content round-trip (agent-readable) ───────────────────────────
  test("agent-readable: content survives full round-trip", () => {
    const expected = new TextEncoder().encode("Hello, World!\n");
    const built = buildPolyglot(zipBuf, "test.zip", {
      strategy: "agent-readable", embedFont: false, embedDiagram: false,
    });
    const extracted = extractPolyglot(built.bytes, {});
    const helloFile = extracted.files.find((f) => f.name === "hello.txt");
    assert(helloFile !== undefined, "hello.txt not found in extracted files");
    assert(helloFile.size === expected.length, `size mismatch: ${helloFile.size} vs ${expected.length}`);
  });

  // ── auto-detect in extractPolyglot ────────────────────────────────────
  test("extractPolyglot auto-detects raw-polyglot-patched without strategy hint", () => {
    const built = buildPolyglot(zipBuf, "test.zip", {
      strategy: "raw-polyglot-patched", embedFont: false, embedDiagram: false,
    });
    const extracted = extractPolyglot(built.bytes /* no strategy hint */);
    assert(extracted.strategy === "raw-polyglot-patched", `got ${extracted.strategy}`);
  });

  // Wait for async tests, then print summary
  await new Promise((r) => setTimeout(r, 100));

  console.log(`\n  ${ passed + failed > 0 ? `${passed} passed, ${failed} failed` : "no tests ran"}\n`);
  if (failed > 0) process.exit(1);
}

main().catch((err) => {
  console.error("Test runner error:", err);
  process.exit(1);
});
