import { test, eq, assert } from "../_harness.mjs";
import { startSovereignServer } from "../../src/http/sovereign-server.ts";
// AUTO-GENERATED contract test from openapi.yaml — do not hand-edit; regenerate.
// Contract: POST /potential/success-path → 200
const SPEC = { method: "post", path: "/potential/success-path", expectStatus: 200 };
// No requestBody defined for this operation.

test("contract computeSuccessPath: POST /potential/success-path is declared", () => {
  assert(SPEC.path.startsWith("/"), "path must be absolute");
  eq(SPEC.method, "post");
});

test("contract computeSuccessPath: POST /potential/success-path is reachable (live, no crash)", async () => {
  const server = startSovereignServer(0);
  const port = (server.address()).port;
  const base = "http://127.0.0.1:" + port;
  try {
    const res = await fetch(base + "/api" + "/potential/success-path", {
      method: "POST",
      headers: { "x-tenant-id": "contract-test-tenant", "content-type": "application/json" },

    });
    // Contract guarantee: route handler runs without crashing the server.
    // 400 (missing/invalid body), 401/403 (auth), 404 (resource not found) are all acceptable —
    // they prove the route is registered and validation ran.
    // 405 would mean the method is not registered on this path.
    // 5xx means the server crashed — a contract violation.
    assert(res.status !== 405, "method must be registered on this path (got 405)");
    assert(res.status < 500, "server must not crash — got " + res.status);
  } finally {
    server.close();
  }
});


