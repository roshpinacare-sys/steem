import { defineConfig } from 'vitest/config';
export default defineConfig({
  test: {
    globals: false,
    environment: 'node',
    include: ['tests/**/*.test.js'],
    coverage: { reporter: ['text', 'lcov'] },
    env: { NODE_ENV: 'test' },
  },
});
