import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, it, expect, vi, beforeEach } from "vitest";
import { runPipeline, type PipelineDeps } from "../../src/cli.js";
import { RedisState } from "../../src/services/redis-state.js";
import { R2Storage } from "../../src/services/r2-storage.js";
import { GitHubClient } from "../../src/services/github-client.js";

const owner = "acme";
const repo = "widget";
const stateKey = `qodo:v24:run:${owner}:${repo}:1`;

let callCount = 0;

vi.mock("../../src/services/ai-router.js", () => ({
  costTracker: {
    reset: vi.fn(),
    charge: vi.fn(),
    breakdown: vi.fn(() => []),
    toTelemetryPayload: vi.fn(() => ({ totalTokens: 0, estimatedUsdCents: 0 })),
  },
  aiRoute: vi.fn(async (path: string) => {
    callCount++;
    if (path === "plan.json") {
      return JSON.stringify({
        steps: [{ id: "1", description: "Add feature", files: ["src/index.ts"] }],
        risk: "low",
        prefetch: ["src/index.ts"],
      });
    }
    if (path === "review.json") {
      return JSON.stringify({ summary: "LGTM", annotations: [] });
    }
    // Coder calls use the target file path
    if (callCount >= 2 && callCount <= 4) {
      return "{ definitely not json";
    }
    return JSON.stringify({
      diff: "--- a/src/index.ts\n+++ b/src/index.ts\n@@ -0,0 +1 @@\n+export const x = 1;\n",
      files: [{ path: "src/index.ts", content: "export const x = 1;\n" }],
    });
  }),
  classifyFile: vi.fn(() => "fast"),
}));

vi.mock("../../src/services/semantic-cache.js", () => ({
  findCachedPatch: vi.fn().mockResolvedValue(null),
  findHiveReference: vi.fn().mockResolvedValue(null),
  saveCachedPatch: vi.fn().mockResolvedValue(undefined),
  saveHivePatch: vi.fn().mockResolvedValue(undefined),
  quarantinePatch: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("../../src/services/health-check.js", () => ({
  runHealthChecks: vi.fn().mockResolvedValue(undefined),
}));

vi.mock("../../src/services/env-validator.js", () => ({
  validateAndCoerce: vi.fn(() => ({
    GITHUB_TOKEN: "ghp_test_token_0000000000000000",
    GROQ_API_KEY: "gsk_test_key_0000000000000000",
    OPENROUTER_API_KEY: "",
    UPSTASH_REDIS_REST_URL: "",
    UPSTASH_REDIS_REST_TOKEN: "",
    REPO: "acme/widget",
    OBJECTIVE: "Add a feature",
    PR_NUMBER: "",
    PR_SHA: "",
    QODO_SKILL_ID: "",
    EDGE_FRAGMENT_WORKER_URL: "",
    VERCEL_TOKEN: "",
    VERCEL_PREVIEW_URL: "",
    VERCEL_PRODUCTION_URL: "",
    QODO_TEST_COMMAND: "npm test",
    QODO_MENTOR_MODE: "",
    NODE_ENV: "test",
  })),
}));

vi.mock("../../src/validators/blast-radius.js", () => ({
  blastRadius: vi.fn().mockResolvedValue({ allowed: true }),
}));
vi.mock("../../src/validators/dom-xray.js", () => ({
  domXray: vi.fn().mockResolvedValue({ allowed: true }),
}));
vi.mock("../../src/validators/shadow-traffic.js", () => ({
  shadowTraffic: vi.fn().mockResolvedValue({ allowed: true }),
}));
vi.mock("../../src/validators/lockfile-guardian.js", () => ({
  lockfileGuardian: vi.fn().mockResolvedValue({ allowed: true }),
}));
vi.mock("../../src/validators/chaos-monkey.js", () => ({
  chaosMonkey: vi.fn().mockResolvedValue({ allowed: true }),
}));

class FakeRedisState extends RedisState {
  private store = new Map<string, string>();
  override async acquireLock() { return true; }
  override async releaseLock() {}
  override async get(key: string) { return this.store.get(key) ?? null; }
  override async set(key: string, value: string) { this.store.set(key, value); }
  override async setWithTTL(key: string, value: string) { this.store.set(key, value); }
  override async delete(key: string) { this.store.delete(key); }
  override async pushEvent(listKey: string, event: Record<string, unknown>) {
    const arr: string[] = this.store.has(listKey) ? JSON.parse(this.store.get(listKey)!) : [];
    arr.unshift(JSON.stringify(event));
    if (arr.length > 10000) arr.length = 10000;
    this.store.set(listKey, JSON.stringify(arr));
  }
}

class FakeR2Storage extends R2Storage {
  private store = new Map<string, string>();
  override async putText(key: string, body: string) { this.store.set(key, body); }
  override async getText(key: string) { return this.store.get(key) ?? ""; }
}

class FakeGitHubClient extends GitHubClient {
  comments: string[] = [];
  constructor(owner: string, repo: string) {
    super("", owner, repo);
  }
  override async getPRShas() { return { base: "base-sha", head: "head-sha" }; }
  override async getFileAtRef() { return ""; }
  override async comment(_pr: number, body: string): Promise<number | undefined> { this.comments.push(body); return undefined; }
  override async checkRun() {}
  /* eslint-disable @typescript-eslint/no-unused-vars */
  override async commitViaGitDB(
    _pr: number,
    _files: { path: string; content: string }[],
    _message: string,
    _expected?: Record<string, string>,
  ) {
    return { commitSha: "commit-sha" };
  }
  /* eslint-enable @typescript-eslint/no-unused-vars */
  override async markPRReady() {}
  override async mergePR() {}
  override async revertCommit() {}
}

describe("runPipeline local simulator", () => {
  beforeEach(() => {
    // Keep the pipeline's audit-log writes out of the repo tree.
    process.env.QODO_WORKSPACE_ROOT = mkdtempSync(join(tmpdir(), "qodo-e2e-"));
    callCount = 0;
    process.env.GITHUB_TOKEN = "ghp_test_token_0000000000000000";
    process.env.GROQ_API_KEY = "gsk_test_key_0000000000000000";
    process.env.UPSTASH_REDIS_REST_URL = "";
    process.env.UPSTASH_REDIS_REST_TOKEN = "";
    process.env.REPO = "acme/widget";
    process.env.OBJECTIVE = "Add a feature";
    process.env.VERCEL_TOKEN = "";
    process.env.VERCEL_PREVIEW_URL = "";
    vi.clearAllMocks();
  });

  it("reaches done, clears state, and records a meta-agent mutation", async () => {
    const state = new FakeRedisState();
    const storage = new FakeR2Storage();
    const gh = new FakeGitHubClient(owner, repo);

    const deps: PipelineDeps = {
      owner,
      repo,
      objective: "Add a feature",
      prNumber: 1,
      prSha: "head-sha",
      gh,
      state,
      storage,
    };

    await runPipeline(deps);

    expect(await state.getJSON(stateKey)).toBeNull();
    expect(await state.getJSON<string>(`prompt_mutations:${owner}:${repo}:coder:active`)).toBeTruthy();
    expect(callCount).toBeGreaterThanOrEqual(5);
  });
});
