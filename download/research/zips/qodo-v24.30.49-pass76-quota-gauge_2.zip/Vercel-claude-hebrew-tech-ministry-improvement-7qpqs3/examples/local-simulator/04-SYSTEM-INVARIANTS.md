# QODO-V24 System Invariants

1. **Phase order is immutable** — The pipeline always advances through `idle → architect → coder → gate → commit → astdoc → canary → merge → postmerge → review → done`. No phase can be skipped or reordered.

2. **No external API calls** — Redis, GitHub, and LLM providers are satisfied by in-memory mocks. No network requests are made.

3. **Determinism** — Given the same objective, the pipeline produces the same run ID, plan, patch, SHAs, and telemetry events.

4. **Schema validation** — Every agent (architect, coder, reviewer) validates LLM output against a Zod schema before downstream phases consume it.

5. **Telemetry completeness** — Each phase logs at least a `phase-start` and a `phase-end` event. Every gate decision is logged with reasoning.

6. **Audit trail** — The Redis and GitHub mocks maintain timestamped audit logs of every operation, enabling replay and introspection.

7. **Artifact flow** — The final `RunState` contains the plan, patch, gate result, PR number, commit SHA, AST doc SHA, canary URL, merged SHA, post-merge SHA, and review.

8. **Gate consensus** — The gate phase advances only when `lockfile-guardian`, `blast-radius`, `dom-xray`, `shadow-traffic`, and `chaos-monkey` all report `passed: true`.

9. **Timestamp monotonicity** — For every phase, `endedAt >= startedAt`, and for the pipeline overall, `completedAt >= startedAt`.

10. **Recovery limits** — On failure the orchestrator retries a fixed number of times (`maxRecoveryAttempts`, default 2). If the phase still fails, the pipeline halts with `phase = done` and records the error.
