import { mkdir, readdir, readFile, stat, writeFile } from "node:fs/promises";
import { createWriteStream } from "node:fs";
import { basename, join, relative, resolve } from "node:path";
import { deflateRawSync } from "node:zlib";

async function* walk(dir: string): AsyncGenerator<string> {
  const entries = await readdir(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = join(dir, entry.name);
    if (entry.isDirectory()) {
      if (["node_modules", ".git", "tasks", ".skills"].includes(entry.name)) continue;
      yield* walk(fullPath);
    } else {
      yield fullPath;
    }
  }
}

async function collectFiles(root: string): Promise<{ path: string; content: Buffer }[]> {
  const files: { path: string; content: Buffer }[] = [];
  for await (const filePath of walk(root)) {
    const rel = relative(root, filePath);
    if (rel === ".env" || rel === "historical_context.txt" || rel.endsWith("package-lock.json")) continue;
    const content = await readFile(filePath);
    files.push({ path: rel, content });
  }
  return files;
}

interface ZipLocalFile {
  name: string;
  content: Buffer;
}

function nameBuffer(str: string): Buffer {
  return Buffer.from(str, "utf-8");
}

let crcTable: number[] | undefined;

function crc32(buf: Buffer): number {
  if (!crcTable) {
    crcTable = [];
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) {
        c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
      }
      crcTable[i] = c;
    }
  }
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc = crcTable[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ -1) >>> 0;
}

function localFileHeader(file: ZipLocalFile, compressed: Buffer, crc: number): Buffer {
  const nameBuf = nameBuffer(file.name);
  const header = Buffer.alloc(30 + nameBuf.length);
  let offset = 0;
  header.writeUInt32LE(0x04034b50, offset);
  offset += 4;
  header.writeUInt16LE(20, offset); // version needed
  offset += 2;
  header.writeUInt16LE(2, offset); // general purpose bit flag (maximum compression)
  offset += 2;
  header.writeUInt16LE(8, offset); // compression method: DEFLATE
  offset += 2;
  header.writeUInt16LE(0, offset); // mod time
  offset += 2;
  header.writeUInt16LE(0, offset); // mod date
  offset += 2;
  header.writeUInt32LE(crc, offset);
  offset += 4;
  header.writeUInt32LE(compressed.length, offset);
  offset += 4;
  header.writeUInt32LE(file.content.length, offset);
  offset += 4;
  header.writeUInt16LE(nameBuf.length, offset);
  offset += 2;
  header.writeUInt16LE(0, offset);
  offset += 2;
  nameBuf.copy(header, offset);
  return header;
}

function buildZip(files: ZipLocalFile[]): Buffer {
  const parts: Buffer[] = [];
  const centralDirectory: {
    name: string;
    localHeaderOffset: number;
    size: number;
    compressed: number;
    crc: number;
  }[] = [];
  let localOffset = 0;

  for (const file of files) {
    const compressed = deflateRawSync(file.content);
    const stored = compressed.length < file.content.length ? compressed : file.content;
    const method: number = compressed.length < file.content.length ? 8 : 0;
    const crc = crc32(file.content);
    const header = localFileHeader(file, stored, crc);
    // Patch compression method if store was chosen (0 is already default in header above, but above hardcodes 8).
    // Simpler: rebuild header with correct method.
    const nameBuf = nameBuffer(file.name);
    const finalHeader = Buffer.alloc(30 + nameBuf.length);
    let p = 0;
    finalHeader.writeUInt32LE(0x04034b50, p);
    p += 4;
    finalHeader.writeUInt16LE(20, p);
    p += 2;
    finalHeader.writeUInt16LE(method === 8 ? 2 : 0, p);
    p += 2;
    finalHeader.writeUInt16LE(method, p);
    p += 2;
    finalHeader.writeUInt16LE(0, p);
    p += 2;
    finalHeader.writeUInt16LE(0, p);
    p += 2;
    finalHeader.writeUInt32LE(crc, p);
    p += 4;
    finalHeader.writeUInt32LE(stored.length, p);
    p += 4;
    finalHeader.writeUInt32LE(file.content.length, p);
    p += 4;
    finalHeader.writeUInt16LE(nameBuf.length, p);
    p += 2;
    finalHeader.writeUInt16LE(0, p);
    p += 2;
    nameBuf.copy(finalHeader, p);

    centralDirectory.push({
      name: file.name,
      localHeaderOffset: localOffset,
      size: file.content.length,
      compressed: stored.length,
      crc,
    });
    parts.push(finalHeader);
    parts.push(stored);
    localOffset += finalHeader.length + stored.length;
  }

  const cdStart = localOffset;
  let cdSize = 0;
  for (const entry of centralDirectory) {
    const nameBuf = nameBuffer(entry.name);
    const method: number = entry.compressed < entry.size ? 8 : 0;
    const cd = Buffer.alloc(46 + nameBuf.length);
    let p = 0;
    cd.writeUInt32LE(0x02014b50, p);
    p += 4;
    cd.writeUInt16LE(20, p);
    p += 2;
    cd.writeUInt16LE(20, p);
    p += 2;
    cd.writeUInt16LE(method === 8 ? 2 : 0, p);
    p += 2;
    cd.writeUInt16LE(method, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt32LE(entry.crc, p);
    p += 4;
    cd.writeUInt32LE(entry.compressed, p);
    p += 4;
    cd.writeUInt32LE(entry.size, p);
    p += 4;
    cd.writeUInt16LE(nameBuf.length, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt16LE(0, p);
    p += 2;
    cd.writeUInt32LE(0, p);
    p += 4;
    cd.writeUInt32LE(entry.localHeaderOffset, p);
    p += 4;
    nameBuf.copy(cd, p);
    parts.push(cd);
    cdSize += cd.length;
  }

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(centralDirectory.length, 8);
  eocd.writeUInt16LE(centralDirectory.length, 10);
  eocd.writeUInt32LE(cdSize, 12);
  eocd.writeUInt32LE(cdStart, 16);
  eocd.writeUInt16LE(0, 20);
  parts.push(eocd);

  return Buffer.concat(parts);
}

async function main(): Promise<void> {
  const root = resolve(process.cwd());
  const outDir = join(root, "tasks");
  await mkdir(outDir, { recursive: true });
  const zipPath = join(outDir, "QODO-V24.30.4.zip");

  const files = await collectFiles(root);
  const zipFiles: ZipLocalFile[] = files.map((f) => ({ name: f.path, content: f.content }));
  const zipBuffer = buildZip(zipFiles);
  await writeFile(zipPath, zipBuffer);

  console.log(`Archive created: ${zipPath}`);
  console.log(`Files included: ${zipFiles.length}`);
  console.log(`Archive size: ${zipBuffer.length} bytes`);
}

main().catch((err) => {
  console.error("Archive generation failed:", err.message);
  process.exit(1);
});
