import { createHash } from "node:crypto";

/**
 * Deterministic SHA generator used by mocks. The same inputs always
 * produce the same SHA fragment.
 */
export function deterministicSha(seed: string, length = 40): string {
  return createHash("sha256").update(seed).digest("hex").slice(0, length);
}

export function generateRunId(objective: string): string {
  return `run-${deterministicSha(objective, 12)}`;
}
