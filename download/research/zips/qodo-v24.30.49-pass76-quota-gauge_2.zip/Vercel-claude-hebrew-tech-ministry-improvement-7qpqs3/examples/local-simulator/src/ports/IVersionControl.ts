/**
 * IVersionControl — port interface for the in-memory GitHub mock.
 *
 * The mock maintains a PR registry, commit history, file system, and
 * check-run state. All SHAs are deterministic given the inputs.
 */
export interface CommitResult {
  sha: string;
  branch: string;
  prNumber: number;
  prUrl: string;
}

export interface PRRecord {
  number: number;
  branch: string;
  title: string;
  state: "open" | "merged" | "closed";
  comments: string[];
  checkRuns: CheckRunRecord[];
  files: Record<string, string>;
  commits: CommitRecord[];
  mergedSha?: string;
}

export interface CommitRecord {
  sha: string;
  message: string;
  files: Record<string, string>;
  timestamp: string;
}

export interface CheckRunRecord {
  id: number;
  name: string;
  sha: string;
  status: "queued" | "in_progress" | "completed";
  conclusion?: string;
  summary?: string;
}

export interface IVersionControl {
  createBranchAndPR(title: string, body?: string): Promise<{ prNumber: number; branch: string; prUrl: string }>;
  commitViaGitDB(
    prNumber: number,
    files: Array<{ path: string; content: string }>,
    message: string,
  ): Promise<CommitResult>;
  mergePR(prNumber: number): Promise<{ mergedSha: string }>;
  getFileAtRef(path: string, ref: string): Promise<string | null>;
  postComment(prNumber: number, body: string): Promise<void>;
  updateCheckRun(
    prNumber: number,
    checkRunId: number,
    status: "in_progress" | "completed",
    conclusion?: string,
    summary?: string,
  ): Promise<void>;
  createCheckRun(prNumber: number, name: string, sha: string): Promise<number>;

  // Introspection
  getPR(prNumber: number): Promise<PRRecord | undefined>;
  getAuditLog(): Promise<Array<{ timestamp: string; op: string; args: unknown[] }>>;
}
