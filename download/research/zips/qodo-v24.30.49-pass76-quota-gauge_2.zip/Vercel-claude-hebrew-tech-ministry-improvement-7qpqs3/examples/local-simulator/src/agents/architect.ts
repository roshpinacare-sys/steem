import type { IStateStore } from "../ports/IStateStore.ts";
import type { AIRouter } from "../ports/AIRouter.ts";
import { Telemetry } from "../utils/telemetry.ts";
import { ArchitectPlanSchema, type ArchitectPlan } from "../schemas/index.ts";

export type Plan = ArchitectPlan;

export interface ArchitectAgent {
  run(objective: string): Promise<Plan>;
}

export class ArchitectAgentImpl implements ArchitectAgent {
  private telemetry: Telemetry;

  private llm: AIRouter;
  private store: IStateStore;
  private runId: string;
  private stream: string;
  constructor(llm: AIRouter, store: IStateStore, runId: string, stream: string) {
    this.llm = llm;
    this.store = store;
    this.runId = runId;
    this.stream = stream;
    this.telemetry = new Telemetry(runId, stream, store);
  }

  async run(objective: string): Promise<Plan> {
    await this.telemetry.log("architect", "architect", "phase-start", { objective });
    const prompt = `You are the ARCHITECT. Break the mission into a JSON plan.\nMission: ${objective}`;
    const { plan, usage } = await this.llm.callArchitect(prompt);

    const parsed = ArchitectPlanSchema.safeParse(plan);
    if (!parsed.success) {
      await this.telemetry.decision("architect", "validation-failed", { errors: parsed.error.issues });
      throw new Error(`Architect plan validation failed: ${parsed.error.message}`);
    }

    await this.store.set(`plan:${this.runId}`, JSON.stringify(parsed.data));
    await this.telemetry.decision("architect", "plan-generated", {
      steps: parsed.data.steps.length,
      confidence: parsed.data.confidence,
      usage,
    });
    await this.telemetry.log("architect", "architect", "phase-end", { steps: parsed.data.steps.length });
    return parsed.data;
  }
}

export function createArchitectAgent(llm: AIRouter, store: IStateStore, runId: string, stream: string): ArchitectAgent {
  return new ArchitectAgentImpl(llm, store, runId, stream);
}
