import type { IStateStore } from "../ports/IStateStore.ts";
import type { AIRouter } from "../ports/AIRouter.ts";
import { Telemetry } from "../utils/telemetry.ts";
import { PatchSchema, type Patch, type ArchitectPlan } from "../schemas/index.ts";

export interface CoderAgent {
  run(objective: string, plan: ArchitectPlan): Promise<Patch>;
}

export class CoderAgentImpl implements CoderAgent {
  private telemetry: Telemetry;

  private llm: AIRouter;
  private store: IStateStore;
  private runId: string;
  private stream: string;
  constructor(llm: AIRouter, store: IStateStore, runId: string, stream: string) {
    this.llm = llm;
    this.store = store;
    this.runId = runId;
    this.stream = stream;
    this.telemetry = new Telemetry(runId, stream, store);
  }

  async run(objective: string, plan: ArchitectPlan): Promise<Patch> {
    await this.telemetry.log("coder", "coder", "phase-start", { objective });
    const prompt = `You are the CODER. Emit JSON {diff, files, tokensUsed, finishReason} implementing the plan.\nObjective: ${objective}\nPlan: ${JSON.stringify(plan)}`;
    const { patch, usage } = await this.llm.callCoder(prompt);

    const parsed = PatchSchema.safeParse(patch);
    if (!parsed.success) {
      await this.telemetry.decision("coder", "validation-failed", { errors: parsed.error.issues });
      throw new Error(`Coder patch validation failed: ${parsed.error.message}`);
    }

    await this.store.set(`patch:${this.runId}`, JSON.stringify(parsed.data));
    await this.telemetry.decision("coder", "patch-generated", {
      files: parsed.data.files.length,
      tokensUsed: parsed.data.tokensUsed,
      usage,
    });
    await this.telemetry.log("coder", "coder", "phase-end", { files: parsed.data.files.length });
    return parsed.data;
  }
}

export function createCoderAgent(llm: AIRouter, store: IStateStore, runId: string, stream: string): CoderAgent {
  return new CoderAgentImpl(llm, store, runId, stream);
}
