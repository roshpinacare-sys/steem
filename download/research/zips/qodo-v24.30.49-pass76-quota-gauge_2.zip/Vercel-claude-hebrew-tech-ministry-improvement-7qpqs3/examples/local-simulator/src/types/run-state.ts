import type { ArchitectPlan } from "../schemas/index.ts";
import type { Patch, Review, Gate } from "../schemas/index.ts";

/**
 * The 11 phases of the QODO-V24 delivery pipeline.
 * Order is load-bearing and enforced by nextPhase().
 */
export const phases = [
  "idle",
  "architect",
  "coder",
  "gate",
  "commit",
  "astdoc",
  "canary",
  "merge",
  "postmerge",
  "review",
  "done",
] as const;

export type Phase = (typeof phases)[number];

export interface GateResult {
  allowed: boolean;
  gates: Gate[];
  summary: string;
}

export interface PhaseTiming {
  startedAt: string;
  endedAt: string;
  durationMs: number;
}

export interface RunState {
  runId: string;
  objective: string;
  phase: Phase;
  plan?: ArchitectPlan;
  patch?: Patch;
  gateResult?: GateResult;
  review?: Review;
  prNumber?: number;
  commitSha?: string;
  astdocSha?: string;
  canaryUrl?: string;
  mergedSha?: string;
  postMergeSha?: string;
  error?: string;
  startedAt: string;
  updatedAt: string;
  completedAt?: string;
  totalDurationMs?: number;
  phaseTimings: Partial<Record<Phase, PhaseTiming>>;
  recoveryAttempts: number;
  telemetryStream: string;
}

export function nextPhase(current: Phase): Phase {
  const index = phases.indexOf(current);
  if (index === -1 || index === phases.length - 1) {
    return "done";
  }
  return phases[index + 1];
}

export function isTerminal(current: Phase): boolean {
  return current === "done";
}

export function initialRunState(runId: string, objective: string, telemetryStream: string): RunState {
  const now = new Date().toISOString();
  return {
    runId,
    objective,
    phase: "idle",
    startedAt: now,
    updatedAt: now,
    phaseTimings: {},
    recoveryAttempts: 0,
    telemetryStream,
  };
}
