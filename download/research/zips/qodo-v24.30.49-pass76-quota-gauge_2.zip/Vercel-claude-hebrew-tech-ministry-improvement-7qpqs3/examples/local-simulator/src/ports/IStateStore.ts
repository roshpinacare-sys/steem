/**
 * IStateStore — port interface for the in-memory Redis mock.
 *
 * All operations are async to mirror real Redis, but the implementation
 * keeps every value in memory with no network I/O.
 */
export interface IStateStore {
  // List operations
  lpush(key: string, value: string): Promise<number>;
  lrange(key: string, start: number, stop: number): Promise<string[]>;

  // String / value operations
  set(key: string, value: string): Promise<void>;
  get(key: string): Promise<string | null>;
  del(key: string): Promise<number>;
  exists(key: string): Promise<number>;
  incr(key: string): Promise<number>;

  // Hash operations
  hset(key: string, field: string, value: string): Promise<number>;
  hget(key: string, field: string): Promise<string | null>;

  // Distributed-style lock
  acquire(lockId: string, ttlMs?: number): Promise<boolean>;
  release(lockId: string): Promise<boolean>;

  // Event / telemetry stream
  pushEvent(stream: string, event: unknown): Promise<void>;
  getEvents(stream: string, limit?: number): Promise<unknown[]>;

  // Introspection helpers used by tests and reporting
  getState(): Promise<Record<string, unknown>>;
  getAuditLog(): Promise<Array<{ timestamp: string; op: string; args: unknown[] }>>;
}
