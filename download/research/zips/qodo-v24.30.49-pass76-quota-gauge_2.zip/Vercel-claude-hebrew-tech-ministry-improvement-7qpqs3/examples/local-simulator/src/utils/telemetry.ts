import type { IStateStore } from "../ports/IStateStore.ts";

export interface TelemetryEvent {
  timestamp: string;
  runId: string;
  phase: string;
  agent: string;
  event: string;
  payload?: Record<string, unknown>;
}

export class Telemetry {
  private runId: string;
  private stream: string;
  private store: IStateStore;

  constructor(runId: string, stream: string, store: IStateStore) {
    this.runId = runId;
    this.stream = stream;
    this.store = store;
  }

  async log(phase: string, agent: string, event: string, payload?: Record<string, unknown>): Promise<void> {
    const entry: TelemetryEvent = {
      timestamp: new Date().toISOString(),
      runId: this.runId,
      phase,
      agent,
      event,
      payload,
    };
    await this.store.pushEvent(this.stream, entry);
  }

  async decision(agent: string, decision: string, payload?: Record<string, unknown>): Promise<void> {
    await this.log("pipeline", agent, `decision:${decision}`, payload);
  }

  async error(agent: string, error: Error, context?: Record<string, unknown>): Promise<void> {
    await this.log("pipeline", agent, "error", {
      ...context,
      message: error.message,
      stack: error.stack,
    });
  }

  async getEvents(limit?: number): Promise<unknown[]> {
    return this.store.getEvents(this.stream, limit);
  }
}

export function createTelemetry(runId: string, stream: string, store: IStateStore): Telemetry {
  return new Telemetry(runId, stream, store);
}
