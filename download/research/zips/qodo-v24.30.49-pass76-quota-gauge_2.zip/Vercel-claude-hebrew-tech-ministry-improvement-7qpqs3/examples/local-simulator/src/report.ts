import type { RunState, Phase } from "./types/run-state.ts";

export interface ReportData {
  state: RunState;
  events: unknown[];
  totalTokens: number;
  estimatedCostUsd: number;
}

export function generateExecutionReport(data: ReportData): string {
  const { state, events, totalTokens, estimatedCostUsd } = data;
  const lines: string[] = [];

  lines.push("# QODO-V24 Execution Report");
  lines.push("");
  lines.push("## Summary");
  lines.push(`- **Run ID:** ${state.runId}`);
  lines.push(`- **Objective:** ${state.objective}`);
  lines.push(`- **Final Phase:** ${state.phase}`);
  lines.push(`- **Status:** ${state.error ? "FAILED" : "SUCCESS"}`);
  lines.push(`- **Started At:** ${state.startedAt}`);
  lines.push(`- **Completed At:** ${state.completedAt || "N/A"}`);
  lines.push(`- **Total Duration:** ${state.totalDurationMs ?? 0}ms`);
  lines.push(`- **Recovery Attempts:** ${state.recoveryAttempts}`);
  lines.push("");

  lines.push("## Phases");
  const allPhases: Phase[] = ["idle", "architect", "coder", "gate", "commit", "astdoc", "canary", "merge", "postmerge", "review", "done"];
  for (const phase of allPhases) {
    const timing = state.phaseTimings[phase];
    const checkbox = timing ? "[x]" : "[ ]";
    const duration = timing ? `${timing.durationMs}ms` : "N/A";
    lines.push(`- ${checkbox} **${phase}** (${duration})`);
  }
  lines.push("");

  lines.push("## Artifacts");
  lines.push(`- **PR Number:** ${state.prNumber ?? "N/A"}`);
  lines.push(`- **Commit SHA:** ${state.commitSha ?? "N/A"}`);
  lines.push(`- **AST Doc SHA:** ${state.astdocSha ?? "N/A"}`);
  lines.push(`- **Canary URL:** ${state.canaryUrl ?? "N/A"}`);
  lines.push(`- **Merged SHA:** ${state.mergedSha ?? "N/A"}`);
  lines.push(`- **Post-Merge SHA:** ${state.postMergeSha ?? "N/A"}`);
  lines.push("");

  lines.push("## Costs");
  lines.push(`- **Total Tokens:** ${totalTokens}`);
  lines.push(`- **Estimated Cost:** $${estimatedCostUsd.toFixed(6)} USD`);
  lines.push("");

  lines.push("## Telemetry");
  lines.push(`Total events: ${events.length}`);
  for (const event of events) {
    const e = event as { timestamp?: string; phase?: string; agent?: string; event?: string; payload?: Record<string, unknown> };
    const payload = e.payload ? ` | ${JSON.stringify(e.payload)}` : "";
    lines.push(`- ${e.timestamp} [${e.phase}] ${e.agent}::${e.event}${payload}`);
  }
  lines.push("");

  if (state.error) {
    lines.push("## Errors");
    lines.push(`- ${state.error}`);
    lines.push("");
  }

  return lines.join("\n");
}

export function printHumanReadable(data: ReportData): void {
  console.log(generateExecutionReport(data));
}
