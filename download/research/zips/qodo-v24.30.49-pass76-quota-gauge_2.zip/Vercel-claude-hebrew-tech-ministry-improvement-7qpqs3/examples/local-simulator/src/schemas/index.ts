import { z } from "zod";

export const StepSchema = z.object({
  id: z.string(),
  description: z.string(),
  files: z.array(z.string()),
  prefetch: z.array(z.string()).optional(),
});

export const ArchitectPlanSchema = z.object({
  objective: z.string(),
  steps: z.array(StepSchema).min(1),
  prefetch: z.array(z.string()).min(1),
  confidence: z.number().min(0).max(1),
  risk: z.enum(["low", "medium", "high"]).default("low"),
});

export type ArchitectPlan = z.infer<typeof ArchitectPlanSchema>;

export const FileChangeSchema = z.object({
  path: z.string(),
  content: z.string(),
});

export const PatchSchema = z.object({
  diff: z.string(),
  files: z.array(FileChangeSchema).min(1),
  tokensUsed: z.number().int().nonnegative(),
  finishReason: z.enum(["stop", "length", "tool_call", "content_filter"]).default("stop"),
});

export type Patch = z.infer<typeof PatchSchema>;

export const AnnotationSchema = z.object({
  path: z.string(),
  start_line: z.number().int().nonnegative(),
  end_line: z.number().int().nonnegative(),
  annotation_level: z.enum(["notice", "warning", "failure"]),
  message: z.string(),
});

export const ReviewSchema = z.object({
  decision: z.enum(["approve", "request_changes", "comment"]),
  score: z.number().min(0).max(100),
  reasoning: z.string(),
  issues: z.array(z.string()),
  suggestions: z.array(z.string()),
  annotations: z.array(AnnotationSchema).optional(),
});

export type Review = z.infer<typeof ReviewSchema>;

export const GateSchema = z.object({
  name: z.string(),
  passed: z.boolean(),
  reasoning: z.string(),
  details: z.record(z.unknown()).optional(),
});

export type Gate = z.infer<typeof GateSchema>;
