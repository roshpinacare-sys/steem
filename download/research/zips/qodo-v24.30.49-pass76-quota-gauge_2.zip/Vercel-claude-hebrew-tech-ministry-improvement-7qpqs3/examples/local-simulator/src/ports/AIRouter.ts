/**
 * AIRouter — port interface for the in-memory LLM mock.
 *
 * Each call returns a deterministic JSON object that matches the
 * consumer's Zod schema. Token usage and cost are tracked locally.
 */
export interface TokenUsage {
  promptTokens: number;
  completionTokens: number;
  totalTokens: number;
  estimatedCostUsd: number;
}

export interface LLMCallRecord {
  timestamp: string;
  role: "architect" | "coder" | "reviewer" | "meta";
  query: string;
  response: unknown;
  usage: TokenUsage;
}

export interface AIRouter {
  callArchitect(prompt: string): Promise<{ plan: unknown; usage: TokenUsage }>;
  callCoder(prompt: string): Promise<{ patch: unknown; usage: TokenUsage }>;
  callReviewer(prompt: string): Promise<{ review: unknown; usage: TokenUsage }>;
  callMetaAgent(prompt: string): Promise<{ decision: unknown; usage: TokenUsage }>;

  // Introspection
  getCalls(): Promise<LLMCallRecord[]>;
  getTotalUsage(): Promise<TokenUsage>;
}
