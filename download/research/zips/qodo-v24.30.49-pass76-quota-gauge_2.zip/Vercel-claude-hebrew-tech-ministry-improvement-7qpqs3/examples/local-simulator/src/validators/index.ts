export { createGateRunner, type GateRunner, type Gate, type GateResult, gateConfigs } from "./gates.ts";
