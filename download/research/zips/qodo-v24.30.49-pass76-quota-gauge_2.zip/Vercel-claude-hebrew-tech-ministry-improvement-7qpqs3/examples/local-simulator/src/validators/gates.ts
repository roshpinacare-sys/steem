import type { IStateStore } from "../ports/IStateStore.ts";
import type { Patch, Gate, GateResult } from "../schemas/index.ts";
import { Telemetry } from "../utils/telemetry.ts";

export type { Gate, GateResult };

export interface GateConfig {
  name: string;
  check(patch: Patch): { passed: boolean; reasoning: string; details?: Record<string, unknown> };
}

/**
 * lockfile-guardian: ensures dependency lockfiles are not silently dropped.
 */
const lockfileGuardian: GateConfig = {
  name: "lockfile-guardian",
  check(patch: Patch) {
    const hasPackageJson = patch.files.some((f) => f.path === "package.json");
    const hasLockfile = patch.files.some((f) => /\/(package-lock\.json|yarn\.lock|pnpm-lock\.yaml)$/.test(f.path));
    if (hasPackageJson && !hasLockfile) {
      return {
        passed: false,
        reasoning: "package.json changed without a corresponding lockfile update.",
        details: { hasPackageJson, hasLockfile },
      };
    }
    return { passed: true, reasoning: "Lockfile consistency preserved.", details: { hasPackageJson, hasLockfile } };
  },
};

/**
 * blast-radius: estimates touched surface area and blocks overly broad changes.
 */
const blastRadius: GateConfig = {
  name: "blast-radius",
  check(patch: Patch) {
    const fileCount = patch.files.length;
    const changedLines = patch.diff.split("\n").length;
    const passed = fileCount <= 10 && changedLines <= 200;
    return {
      passed,
      reasoning: passed
        ? `Blast radius acceptable (${fileCount} files, ~${changedLines} diff lines).`
        : `Blast radius too large (${fileCount} files, ~${changedLines} diff lines).`,
      details: { fileCount, changedLines },
    };
  },
};

/**
 * dom-xray: blocks unsafe DOM patterns in HTML/JS content.
 */
const domXray: GateConfig = {
  name: "dom-xray",
  check(patch: Patch) {
    const risky = /(eval\s*\(|innerHTML\s*=|document\.write\()/;
    const matches: string[] = [];
    for (const file of patch.files) {
      if (risky.test(file.content)) {
        matches.push(file.path);
      }
    }
    return {
      passed: matches.length === 0,
      reasoning: matches.length === 0 ? "No unsafe DOM sinks detected." : `Unsafe DOM sinks found in ${matches.join(", ")}.`,
      details: { matches },
    };
  },
};

/**
 * shadow-traffic: simulates a canary request by verifying endpoints are reachable in mock content.
 */
const shadowTraffic: GateConfig = {
  name: "shadow-traffic",
  check(patch: Patch) {
    const hasRoute = patch.files.some((f) => /(router|route|handler|endpoint)/i.test(f.content + f.path));
    const passed = !hasRoute || patch.files.some((f) => /health|ping|status/i.test(f.content + f.path));
    return {
      passed,
      reasoning: passed
        ? "Shadow traffic route coverage looks acceptable."
        : "Routes were modified but no health/readiness endpoint was found.",
      details: { hasRoute },
    };
  },
};

/**
 * chaos-monkey: injects a deterministic failure chance based on patch content hash.
 */
const chaosMonkey: GateConfig = {
  name: "chaos-monkey",
  check(patch: Patch) {
    const content = patch.files.map((f) => f.content).join("");
    const deterministicScore = content.length % 100;
    const passed = deterministicScore >= 5; // 95% pass rate deterministically
    return {
      passed,
      reasoning: passed
        ? `Chaos score ${deterministicScore}/100 within tolerance.`
        : `Chaos score ${deterministicScore}/100 triggered synthetic failure.`,
      details: { deterministicScore },
    };
  },
};

export const gateConfigs: GateConfig[] = [lockfileGuardian, blastRadius, domXray, shadowTraffic, chaosMonkey];

export interface GateRunner {
  run(patch: Patch): Promise<GateResult>;
}

export class GateRunnerImpl implements GateRunner {
  private telemetry: Telemetry;

  private store: IStateStore;
  private runId: string;
  private stream: string;
  constructor(store: IStateStore, runId: string, stream: string) {
    this.store = store;
    this.runId = runId;
    this.stream = stream;
    this.telemetry = new Telemetry(runId, stream, store);
  }

  async run(patch: Patch): Promise<GateResult> {
    await this.telemetry.log("gate", "gate-runner", "phase-start", { gates: gateConfigs.length });
    const gates: Gate[] = gateConfigs.map((config) => {
      const result = config.check(patch);
      return { name: config.name, passed: result.passed, reasoning: result.reasoning, details: result.details };
    });

    for (const gate of gates) {
      await this.telemetry.decision("gate", gate.name, { passed: gate.passed, reasoning: gate.reasoning });
    }

    const allowed = gates.every((g) => g.passed);
    const gateResult: GateResult = {
      allowed,
      gates,
      summary: allowed ? "All validation gates passed." : `Gate(s) failed: ${gates.filter((g) => !g.passed).map((g) => g.name).join(", ")}.`,
    };

    await this.store.set(`gate:${this.runId}`, JSON.stringify(gateResult));
    await this.telemetry.decision("gate", "gate-result", { allowed, summary: gateResult.summary });
    await this.telemetry.log("gate", "gate-runner", "phase-end", { allowed });
    return gateResult;
  }
}

export function createGateRunner(store: IStateStore, runId: string, stream: string): GateRunner {
  return new GateRunnerImpl(store, runId, stream);
}
