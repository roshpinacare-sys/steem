import type { IStateStore } from "../ports/IStateStore.ts";
import type { AIRouter } from "../ports/AIRouter.ts";
import { Telemetry } from "../utils/telemetry.ts";
import { ReviewSchema, type Review, type Patch } from "../schemas/index.ts";

export interface ReviewerAgent {
  run(objective: string, patch: Patch): Promise<Review>;
}

export class ReviewerAgentImpl implements ReviewerAgent {
  private telemetry: Telemetry;

  private llm: AIRouter;
  private store: IStateStore;
  private runId: string;
  private stream: string;
  constructor(llm: AIRouter, store: IStateStore, runId: string, stream: string) {
    this.llm = llm;
    this.store = store;
    this.runId = runId;
    this.stream = stream;
    this.telemetry = new Telemetry(runId, stream, store);
  }

  async run(objective: string, patch: Patch): Promise<Review> {
    await this.telemetry.log("review", "reviewer", "phase-start", { objective });
    const prompt = `You are the REVIEWER. Return JSON {decision, score, reasoning, issues, suggestions, annotations?} for the diff.\nObjective: ${objective}\nDiff:\n${patch.diff}`;
    const { review, usage } = await this.llm.callReviewer(prompt);

    const parsed = ReviewSchema.safeParse(review);
    if (!parsed.success) {
      await this.telemetry.decision("reviewer", "validation-failed", { errors: parsed.error.issues });
      throw new Error(`Reviewer output validation failed: ${parsed.error.message}`);
    }

    await this.store.set(`review:${this.runId}`, JSON.stringify(parsed.data));
    await this.telemetry.decision("reviewer", "review-complete", {
      decision: parsed.data.decision,
      score: parsed.data.score,
      usage,
    });
    await this.telemetry.log("review", "reviewer", "phase-end", { decision: parsed.data.decision });
    return parsed.data;
  }
}

export function createReviewerAgent(llm: AIRouter, store: IStateStore, runId: string, stream: string): ReviewerAgent {
  return new ReviewerAgentImpl(llm, store, runId, stream);
}
