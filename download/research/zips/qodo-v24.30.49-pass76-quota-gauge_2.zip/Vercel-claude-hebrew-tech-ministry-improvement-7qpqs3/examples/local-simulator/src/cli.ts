#!/usr/bin/env node
import { createRedisMock } from "../mocks/redis-mock.ts";
import { createGitHubMock } from "../mocks/github-mock.ts";
import { createLLMMock } from "../mocks/llm-mock.ts";
import { runPipeline } from "./pipeline.ts";
import { generateExecutionReport } from "./report.ts";
import { writeFileSync } from "node:fs";
import { resolve } from "node:path";

function parseArgs(argv: string[]): { objective: string; dryRun: boolean } {
  const args = argv.slice(2);
  const dryRun = args.includes("--dry-run");
  const positional = args.filter((a) => a !== "--dry-run").join(" ").trim();
  const objective = positional || (process.env.QODO_OBJECTIVE ?? "default test objective");
  return { objective, dryRun };
}

function validateObjective(objective: string): void {
  if (objective.length === 0) {
    throw new Error("Objective cannot be empty.");
  }
  if (objective.length > 500) {
    throw new Error("Objective exceeds maximum length of 500 characters.");
  }
}

async function main(): Promise<void> {
  const { objective, dryRun } = parseArgs(process.argv);
  validateObjective(objective);

  console.log(`QODO-V24 Pipeline Starting`);
  console.log(`Objective: ${objective}`);
  if (dryRun) {
    console.log("Mode: dry-run (no persistent side effects)");
  }
  console.log("-".repeat(60));

  const start = performance.now();
  const store = createRedisMock();
  const github = createGitHubMock();
  const llm = createLLMMock();

  try {
    const result = await runPipeline({ objective, store, github, llm });
    const duration = Math.round(performance.now() - start);

    console.log(`\nPipeline completed in ${duration}ms`);
    console.log(`Final phase: ${result.state.phase}`);
    console.log(`PR Number: ${result.state.prNumber ?? "N/A"}`);
    console.log(`Commit SHA: ${result.state.commitSha ?? "N/A"}`);
    console.log(`Merged SHA: ${result.state.mergedSha ?? "N/A"}`);
    console.log(`Total tokens: ${result.totalUsage.totalTokens}`);
    console.log(`Telemetry events: ${result.events.length}`);

    if (!dryRun) {
      const reportPath = resolve(process.cwd(), "EXECUTION_REPORT.md");
      const report = generateExecutionReport({
        state: result.state,
        events: result.events,
        totalTokens: result.totalUsage.totalTokens,
        estimatedCostUsd: result.totalUsage.estimatedCostUsd,
      });
      writeFileSync(reportPath, report);
      console.log(`\nExecution report written to ${reportPath}`);
    } else {
      console.log("\nDry-run complete. No execution report was written.");
    }

    process.exit(result.state.error ? 1 : 0);
  } catch (error) {
    console.error("Pipeline crashed:", (error as Error).message);
    process.exit(1);
  }
}

main();
