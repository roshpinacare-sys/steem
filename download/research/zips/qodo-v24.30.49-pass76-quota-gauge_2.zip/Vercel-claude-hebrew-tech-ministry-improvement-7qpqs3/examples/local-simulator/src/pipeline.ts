import type { IStateStore } from "./ports/IStateStore.ts";
import type { IVersionControl } from "./ports/IVersionControl.ts";
import type { AIRouter } from "./ports/AIRouter.ts";
import { createArchitectAgent, createCoderAgent, createReviewerAgent } from "./agents/index.ts";
import { createGateRunner } from "./validators/index.ts";
import { Telemetry } from "./utils/telemetry.ts";
import { generateRunId } from "./utils/hash.ts";
import { nextPhase, initialRunState, type RunState, type Phase } from "./types/run-state.ts";

export interface PipelineContext {
  objective: string;
  store: IStateStore;
  github: IVersionControl;
  llm: AIRouter;
  maxRecoveryAttempts?: number;
}

export interface PipelineResult {
  state: RunState;
  events: unknown[];
  totalUsage: { totalTokens: number; estimatedCostUsd: number };
}

export class PipelineOrchestrator {
  private state: RunState;
  private telemetry: Telemetry;
  private ctx: PipelineContext;

  constructor(ctx: PipelineContext) {
    this.ctx = ctx;
    const runId = generateRunId(ctx.objective);
    const stream = `telemetry:${runId}`;
    this.state = initialRunState(runId, ctx.objective, stream);
    this.telemetry = new Telemetry(runId, stream, ctx.store);
  }

  async run(): Promise<PipelineResult> {
    await this.telemetry.log("idle", "orchestrator", "pipeline-start", { objective: this.ctx.objective });

    while (!this.isDone()) {
      const current = this.state.phase;
      const next = nextPhase(current);
      if (next === current) break;

      const startedAt = new Date().toISOString();
      await this.telemetry.log(current, "orchestrator", "phase-start", { phase: current, next });

      let shouldAdvance = true;
      try {
        await this.executePhase(current);
        this.state.error = undefined;
      } catch (error) {
        shouldAdvance = await this.handleError(current, error as Error);
      }

      const endedAt = new Date().toISOString();
      const durationMs = new Date(endedAt).getTime() - new Date(startedAt).getTime();
      this.state.phaseTimings[current] = { startedAt, endedAt, durationMs };
      this.state.updatedAt = endedAt;

      await this.telemetry.log(current, "orchestrator", "phase-end", { phase: current, durationMs, shouldAdvance });

      if (shouldAdvance) {
        this.state.phase = next;
      }
      await this.storeState();
    }

    const completedAt = new Date().toISOString();
    this.state.completedAt = completedAt;
    this.state.totalDurationMs =
      new Date(completedAt).getTime() - new Date(this.state.startedAt).getTime();
    this.state.updatedAt = completedAt;
    this.state.phaseTimings["done"] = {
      startedAt: completedAt,
      endedAt: completedAt,
      durationMs: 0,
    };
    await this.telemetry.log("done", "orchestrator", "phase-start", { phase: "done" });
    await this.telemetry.log("done", "orchestrator", "pipeline-done", {
      totalDurationMs: this.state.totalDurationMs,
    });
    await this.telemetry.log("done", "orchestrator", "phase-end", { phase: "done" });
    await this.storeState();

    const usage = await this.ctx.llm.getTotalUsage();
    const events = await this.ctx.store.getEvents(this.state.telemetryStream);
    return { state: this.state, events, totalUsage: usage };
  }

  private isDone(): boolean {
    return this.state.phase === "done";
  }

  private async executePhase(phase: Phase): Promise<void> {
    switch (phase) {
      case "idle": {
        await this.telemetry.decision("orchestrator", "idle-complete", { runId: this.state.runId });
        break;
      }
      case "architect": {
        const architect = createArchitectAgent(this.ctx.llm, this.ctx.store, this.state.runId, this.state.telemetryStream);
        this.state.plan = await architect.run(this.ctx.objective);
        break;
      }
      case "coder": {
        if (!this.state.plan) throw new Error("Missing plan before coder phase");
        const coder = createCoderAgent(this.ctx.llm, this.ctx.store, this.state.runId, this.state.telemetryStream);
        this.state.patch = await coder.run(this.ctx.objective, this.state.plan);
        break;
      }
      case "gate": {
        if (!this.state.patch) throw new Error("Missing patch before gate phase");
        const gateRunner = createGateRunner(this.ctx.store, this.state.runId, this.state.telemetryStream);
        this.state.gateResult = await gateRunner.run(this.state.patch);
        if (!this.state.gateResult.allowed) {
          throw new Error(`Gate validation failed: ${this.state.gateResult.summary}`);
        }
        break;
      }
      case "commit": {
        if (!this.state.patch) throw new Error("Missing patch before commit phase");
        const { prNumber, branch, prUrl } = await this.ctx.github.createBranchAndPR(this.ctx.objective);
        this.state.prNumber = prNumber;
        const commit = await this.ctx.github.commitViaGitDB(prNumber, this.state.patch.files, `QODO-V24: ${this.ctx.objective}`);
        this.state.commitSha = commit.sha;
        const checkId = await this.ctx.github.createCheckRun(prNumber, "qodo-ci", commit.sha);
        await this.ctx.github.updateCheckRun(prNumber, checkId, "completed", "success", "All checks passed");
        await this.telemetry.decision("commit", "commit-created", { prNumber, branch, prUrl, sha: commit.sha, checkId });
        break;
      }
      case "astdoc": {
        if (!this.state.commitSha || !this.state.prNumber) throw new Error("Missing commit before astdoc phase");
        const astdocFiles = [
          { path: "docs/ast-changes.md", content: `# AST Changes\n\n- Updated objective: ${this.ctx.objective}\n- Commit: ${this.state.commitSha}\n` },
        ];
        const astdocCommit = await this.ctx.github.commitViaGitDB(this.state.prNumber, astdocFiles, "QODO-V24: AST documentation");
        this.state.astdocSha = astdocCommit.sha;
        await this.telemetry.decision("astdoc", "astdoc-created", { sha: astdocCommit.sha });
        break;
      }
      case "canary": {
        if (!this.state.prNumber) throw new Error("Missing PR number before canary phase");
        this.state.canaryUrl = `https://canary.qodo.dev/pr/${this.state.prNumber}`;
        await this.ctx.github.postComment(this.state.prNumber, `Canary deployed: ${this.state.canaryUrl}`);
        await this.telemetry.decision("canary", "canary-deployed", { url: this.state.canaryUrl });
        break;
      }
      case "merge": {
        if (!this.state.prNumber) throw new Error("Missing PR number before merge phase");
        const { mergedSha } = await this.ctx.github.mergePR(this.state.prNumber);
        this.state.mergedSha = mergedSha;
        await this.telemetry.decision("merge", "pr-merged", { prNumber: this.state.prNumber, mergedSha });
        break;
      }
      case "postmerge": {
        if (!this.state.mergedSha) throw new Error("Missing merged SHA before postmerge phase");
        this.state.postMergeSha = `post-${this.state.mergedSha}`;
        await this.ctx.github.postComment(this.state.prNumber!, `Post-merge verification passed for ${this.state.postMergeSha}`);
        await this.telemetry.decision("postmerge", "postmerge-verified", { postMergeSha: this.state.postMergeSha });
        break;
      }
      case "review": {
        if (!this.state.patch) throw new Error("Missing patch before review phase");
        const reviewer = createReviewerAgent(this.ctx.llm, this.ctx.store, this.state.runId, this.state.telemetryStream);
        this.state.review = await reviewer.run(this.ctx.objective, this.state.patch);
        await this.telemetry.decision("review", "human-review-emulated", { decision: this.state.review.decision });
        break;
      }
      case "done":
        break;
    }
  }

  private async handleError(phase: Phase, error: Error): Promise<boolean> {
    this.state.error = error.message;
    await this.telemetry.error("orchestrator", error, { phase });

    if (this.state.recoveryAttempts < (this.ctx.maxRecoveryAttempts ?? 2)) {
      this.state.recoveryAttempts++;
      await this.telemetry.decision("orchestrator", "recovery-attempt", { phase, attempt: this.state.recoveryAttempts });
      // Retry the same phase by not advancing.
      return false;
    }

    await this.telemetry.decision("orchestrator", "halt", { phase, error: error.message });
    this.state.phase = "done";
    // Returning false prevents the run loop from advancing to the next phase;
    // the while loop will now terminate because phase is terminal.
    return false;
  }

  private async storeState(): Promise<void> {
    await this.ctx.store.set(`run:${this.state.runId}`, JSON.stringify(this.state));
  }
}

export async function runPipeline(ctx: PipelineContext): Promise<PipelineResult> {
  const orchestrator = new PipelineOrchestrator(ctx);
  return orchestrator.run();
}
