# Local Simulator (formerly `standalone-executable/`)

A **mock-only, zero-external-dependency harness** that simulates the Qodo
pipeline flow (architect → coder → gates → report) entirely in-process, using
`mocks/{github,llm,redis}-mock.ts` and Node ≥24's `--experimental-strip-types`.

**This is NOT the product and NOT shared code.** It is a *diverged fork* of
the real agent written for demos and pipeline-logic experiments:

- The real agent lives in `packages/agent/` — ~17k lines, real integrations.
- This harness is ~2k lines with the same *concept names* (architect, coder,
  reviewer, ports, validators) but entirely different implementations.
- Do not fix product bugs here first, and do not assume behavior here
  matches `packages/agent`.

## Run it

```bash
cd examples/local-simulator
npm install       # zod only
npm test          # 28 mock-pipeline tests
```

Its tests also run in CI (the `simulator` job) and via `npm run
test:examples` at the repo root.
