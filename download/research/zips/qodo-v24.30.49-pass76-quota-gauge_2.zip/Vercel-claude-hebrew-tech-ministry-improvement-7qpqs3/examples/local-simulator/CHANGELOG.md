# Changelog

## 24.30.4

### Fixed
- `PipelineOrchestrator` now clears `RunState.error` after a phase succeeds, preventing stale error messages from appearing in successful runs that previously recovered from transient failures.

### Added
- Integration test verifying recovery from a transient `architect` failure and confirming the final state has no blocking error.
- Integration test verifying the pipeline halts and preserves the error after exhausting recovery attempts.
- `--dry-run` CLI flag to simulate a pipeline run without writing `EXECUTION_REPORT.md`.
- CLI validation for empty or overly long objectives.
- DEFLATE compression for the release ZIP archive.

### Changed
- Archive generator now excludes `historical_context.txt` and `package-lock.json` from the release bundle.
- Release archive renamed to `QODO-V24.30.4.zip`.
