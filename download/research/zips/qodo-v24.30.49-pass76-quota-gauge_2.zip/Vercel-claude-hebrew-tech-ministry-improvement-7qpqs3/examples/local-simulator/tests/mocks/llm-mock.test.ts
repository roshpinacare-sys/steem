import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createLLMMock } from "../../mocks/llm-mock.ts";

describe("LLMMock", () => {
  it("returns deterministic architect plans", async () => {
    const llm = createLLMMock();
    const { plan } = await llm.callArchitect("add greeting");
    assert.ok(Array.isArray((plan as { steps: unknown[] }).steps));
    assert.equal((plan as { objective: string }).objective, "add greeting");
  });

  it("tracks token usage across calls", async () => {
    const llm = createLLMMock();
    await llm.callArchitect("x");
    await llm.callCoder("x");
    await llm.callReviewer("x");
    const usage = await llm.getTotalUsage();
    assert.ok(usage.totalTokens > 0);
    assert.ok(usage.estimatedCostUsd > 0);
    const calls = await llm.getCalls();
    assert.equal(calls.length, 3);
  });
});
