import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { nextPhase, phases, initialRunState } from "../../src/types/run-state.ts";

describe("run-state", () => {
  it("advances through the 11 phases in order", () => {
    let phase = phases[0];
    const visited: string[] = [phase];
    while (phase !== "done") {
      phase = nextPhase(phase);
      visited.push(phase);
    }
    assert.deepEqual(visited, phases);
  });

  it("stays at done when already terminal", () => {
    assert.equal(nextPhase("done"), "done");
  });

  it("initialises a valid run state", () => {
    const state = initialRunState("run-x", "test", "stream");
    assert.equal(state.runId, "run-x");
    assert.equal(state.objective, "test");
    assert.equal(state.phase, "idle");
    assert.equal(state.recoveryAttempts, 0);
  });
});
