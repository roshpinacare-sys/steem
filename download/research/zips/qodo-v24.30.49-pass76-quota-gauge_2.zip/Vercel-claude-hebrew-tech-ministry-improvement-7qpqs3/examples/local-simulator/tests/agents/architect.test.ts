import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";
import { createLLMMock } from "../../mocks/llm-mock.ts";
import { createArchitectAgent } from "../../src/agents/architect.ts";

describe("ArchitectAgent", () => {
  it("generates and stores a validated plan", async () => {
    const store = createRedisMock();
    const llm = createLLMMock();
    const agent = createArchitectAgent(llm, store, "run-1", "telemetry:run-1");
    const plan = await agent.run("add a greeting endpoint");

    assert.equal(plan.objective, "add a greeting endpoint");
    assert.ok(plan.steps.length > 0);
    assert.ok(plan.confidence >= 0 && plan.confidence <= 1);

    const stored = await store.get("plan:run-1");
    assert.ok(stored);
    const parsed = JSON.parse(stored!);
    assert.equal(parsed.steps.length, plan.steps.length);
  });

  it("logs telemetry events", async () => {
    const store = createRedisMock();
    const llm = createLLMMock();
    const agent = createArchitectAgent(llm, store, "run-2", "telemetry:run-2");
    await agent.run("objective");
    const events = await store.getEvents("telemetry:run-2");
    assert.ok(events.length >= 2);
  });
});
