import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";
import { createGateRunner, gateConfigs } from "../../src/validators/gates.ts";
import { PatchSchema } from "../../src/schemas/index.ts";

describe("GateRunner", () => {
  it("passes all gates for a minimal safe patch", async () => {
    const store = createRedisMock();
    const runner = createGateRunner(store, "run-g1", "telemetry:run-g1");
    const patch = PatchSchema.parse({
      diff: "@@ -1 +1 @@\n-old\n+new",
      files: [{ path: "src/index.ts", content: "export const x = 1;" }],
      tokensUsed: 10,
      finishReason: "stop",
    });
    const result = await runner.run(patch);
    assert.equal(result.allowed, true);
    assert.equal(result.gates.length, 5);
    assert.ok(result.gates.every((g) => g.passed));
  });

  it("fails dom-xray for unsafe content", async () => {
    const store = createRedisMock();
    const runner = createGateRunner(store, "run-g2", "telemetry:run-g2");
    const patch = PatchSchema.parse({
      diff: "@@ -1 +1 @@\n-eval(x)",
      files: [{ path: "src/index.ts", content: "eval('bad')" }],
      tokensUsed: 10,
      finishReason: "stop",
    });
    const result = await runner.run(patch);
    assert.equal(result.allowed, false);
    const dom = result.gates.find((g) => g.name === "dom-xray");
    assert.equal(dom?.passed, false);
  });
});

describe("gateConfigs", () => {
  it("contains five named validators", () => {
    const names = gateConfigs.map((g) => g.name);
    assert.deepEqual(names, ["lockfile-guardian", "blast-radius", "dom-xray", "shadow-traffic", "chaos-monkey"]);
  });
});
