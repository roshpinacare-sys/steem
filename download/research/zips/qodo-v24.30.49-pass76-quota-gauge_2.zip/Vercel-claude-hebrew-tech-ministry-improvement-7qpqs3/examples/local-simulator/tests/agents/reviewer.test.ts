import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";
import { createLLMMock } from "../../mocks/llm-mock.ts";
import { createReviewerAgent } from "../../src/agents/reviewer.ts";
import { PatchSchema } from "../../src/schemas/index.ts";

describe("ReviewerAgent", () => {
  it("returns a validated review", async () => {
    const store = createRedisMock();
    const llm = createLLMMock();
    const agent = createReviewerAgent(llm, store, "run-5", "telemetry:run-5");
    const patch = PatchSchema.parse({
      diff: "@@ -1 +1 @@\n-old\n+new",
      files: [{ path: "src/index.ts", content: "export const x = 1;" }],
      tokensUsed: 10,
      finishReason: "stop",
    });
    const review = await agent.run("update value", patch);

    assert.ok(["approve", "request_changes", "comment"].includes(review.decision));
    assert.ok(review.score >= 0 && review.score <= 100);
    assert.ok(review.reasoning.length > 0);

    const stored = await store.get("review:run-5");
    assert.ok(stored);
  });
});
