import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";
import { createLLMMock } from "../../mocks/llm-mock.ts";
import { createCoderAgent } from "../../src/agents/coder.ts";
import { ArchitectPlanSchema } from "../../src/schemas/index.ts";

describe("CoderAgent", () => {
  it("generates and stores a validated patch", async () => {
    const store = createRedisMock();
    const llm = createLLMMock();
    const agent = createCoderAgent(llm, store, "run-3", "telemetry:run-3");
    const plan = ArchitectPlanSchema.parse({
      objective: "add greeting",
      steps: [{ id: "s1", description: "change greeting", files: ["src/index.ts"] }],
      prefetch: ["src/index.ts"],
      confidence: 0.9,
    });
    const patch = await agent.run("add greeting", plan);

    assert.ok(patch.files.length > 0);
    assert.ok(patch.diff.length > 0);
    assert.equal(patch.finishReason, "stop");

    const stored = await store.get("patch:run-3");
    assert.ok(stored);
  });

  it("logs telemetry events", async () => {
    const store = createRedisMock();
    const llm = createLLMMock();
    const agent = createCoderAgent(llm, store, "run-4", "telemetry:run-4");
    const plan = ArchitectPlanSchema.parse({
      objective: "x",
      steps: [{ id: "s1", description: "x", files: ["src/index.ts"] }],
      prefetch: ["src/index.ts"],
      confidence: 0.5,
    });
    await agent.run("x", plan);
    const events = await store.getEvents("telemetry:run-4");
    assert.ok(events.length >= 2);
  });
});
