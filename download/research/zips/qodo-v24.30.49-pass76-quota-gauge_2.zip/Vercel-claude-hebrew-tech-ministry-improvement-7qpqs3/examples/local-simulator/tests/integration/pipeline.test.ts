import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";
import { createGitHubMock } from "../../mocks/github-mock.ts";
import { createLLMMock } from "../../mocks/llm-mock.ts";
import { runPipeline } from "../../src/pipeline.ts";
import { phases, type Phase } from "../../src/types/run-state.ts";
import type { AIRouter, TokenUsage, LLMCallRecord } from "../../src/ports/AIRouter.ts";

describe("Pipeline Integration", () => {
  it("executes all 11 phases in order", async () => {
    const store = createRedisMock();
    const github = createGitHubMock();
    const llm = createLLMMock();
    const result = await runPipeline({ objective: "add greeting endpoint", store, github, llm });

    assert.equal(result.state.phase, "done");
    assert.equal(result.state.error, undefined);
    assert.ok(result.state.plan);
    assert.ok(result.state.patch);
    assert.ok(result.state.gateResult);
    assert.ok(result.state.gateResult?.allowed);
    assert.ok(typeof result.state.prNumber === "number");
    assert.ok(result.state.commitSha);
    assert.ok(result.state.astdocSha);
    assert.ok(result.state.canaryUrl);
    assert.ok(result.state.mergedSha);
    assert.ok(result.state.postMergeSha);
    assert.ok(result.state.review);
  });

  it("never skips or reorders phases", async () => {
    const store = createRedisMock();
    const github = createGitHubMock();
    const llm = createLLMMock();
    const result = await runPipeline({ objective: "reorder test", store, github, llm });
    const recorded = phases.filter((p) => result.state.phaseTimings[p]);
    assert.deepEqual(recorded, phases.slice(0, phases.indexOf("done") + 1));
  });

  it("records telemetry for every phase", async () => {
    const store = createRedisMock();
    const github = createGitHubMock();
    const llm = createLLMMock();
    const result = await runPipeline({ objective: "telemetry test", store, github, llm });
    assert.ok(result.events.length >= 20);
    const eventPhases = new Set(
      result.events.map((e) => (e as { phase: string }).phase),
    );
    const expectedPhases: Phase[] = ["idle", "architect", "coder", "gate", "commit", "astdoc", "canary", "merge", "postmerge", "review", "done"];
    for (const phase of expectedPhases) {
      assert.ok(eventPhases.has(phase), `missing telemetry for phase ${phase}`);
    }
  });

  it("produces deterministic output for the same objective", async () => {
    const run = async () => {
      const store = createRedisMock();
      const github = createGitHubMock();
      const llm = createLLMMock();
      return runPipeline({ objective: "determinism test", store, github, llm });
    };
    const a = await run();
    const b = await run();
    assert.equal(a.state.runId, b.state.runId);
    assert.equal(a.state.plan?.objective, b.state.plan?.objective);
    assert.equal(a.state.commitSha, b.state.commitSha);
    assert.equal(a.state.mergedSha, b.state.mergedSha);
  });

  it("recovers from a transient architect failure and clears the error", async () => {
    const base = createLLMMock();
    let calls = 0;
    const flaky: AIRouter = {
      async callArchitect(prompt: string): Promise<{ plan: unknown; usage: TokenUsage }> {
        calls++;
        if (calls === 1) {
          throw new Error("transient architect failure");
        }
        return base.callArchitect(prompt);
      },
      async callCoder(prompt: string): Promise<{ patch: unknown; usage: TokenUsage }> {
        return base.callCoder(prompt);
      },
      async callReviewer(prompt: string): Promise<{ review: unknown; usage: TokenUsage }> {
        return base.callReviewer(prompt);
      },
      async callMetaAgent(prompt: string): Promise<{ decision: unknown; usage: TokenUsage }> {
        return base.callMetaAgent(prompt);
      },
      async getCalls(): Promise<LLMCallRecord[]> {
        return base.getCalls();
      },
      async getTotalUsage(): Promise<TokenUsage> {
        return base.getTotalUsage();
      },
    };

    const store = createRedisMock();
    const github = createGitHubMock();
    const result = await runPipeline({ objective: "recovery test", store, github, llm: flaky, maxRecoveryAttempts: 2 });

    assert.equal(result.state.phase, "done");
    assert.equal(result.state.error, undefined);
    assert.ok(result.state.plan);
    assert.equal(calls, 2);
  });

  it("halts after exhausting recovery attempts and preserves the error", async () => {
    const alwaysFailing: AIRouter = {
      async callArchitect(): Promise<{ plan: unknown; usage: TokenUsage }> {
        throw new Error("persistent architect failure");
      },
      async callCoder(): Promise<{ patch: unknown; usage: TokenUsage }> {
        throw new Error("unreachable");
      },
      async callReviewer(): Promise<{ review: unknown; usage: TokenUsage }> {
        throw new Error("unreachable");
      },
      async callMetaAgent(): Promise<{ decision: unknown; usage: TokenUsage }> {
        throw new Error("unreachable");
      },
      async getCalls(): Promise<LLMCallRecord[]> {
        return [];
      },
      async getTotalUsage(): Promise<TokenUsage> {
        return { promptTokens: 0, completionTokens: 0, totalTokens: 0, estimatedCostUsd: 0 };
      },
    };

    const store = createRedisMock();
    const github = createGitHubMock();
    const result = await runPipeline({ objective: "halt test", store, github, llm: alwaysFailing, maxRecoveryAttempts: 1 });

    assert.equal(result.state.phase, "done");
    assert.equal(result.state.error, "persistent architect failure");
    assert.equal(result.state.plan, undefined);
  });
});
