#!/usr/bin/env node
import { createRedisMock } from "../mocks/redis-mock.ts";
import { createGitHubMock } from "../mocks/github-mock.ts";
import { createLLMMock } from "../mocks/llm-mock.ts";
import { runPipeline } from "../src/pipeline.ts";
import { phases, type RunState, type Phase } from "../src/types/run-state.ts";

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(`VALIDATION FAILED: ${message}`);
  }
}

async function validate(): Promise<void> {
  const store = createRedisMock();
  const github = createGitHubMock();
  const llm = createLLMMock();
  const result = await runPipeline({ objective: "validation run", store, github, llm });
  const state = result.state;

  // 1. Final phase must be done with no blocking error.
  assert(state.phase === "done", `expected done, got ${state.phase}`);
  assert(!state.error, `pipeline ended with error: ${state.error}`);

  // 2. All required fields are present.
  assert(state.runId, "missing runId");
  assert(state.objective, "missing objective");
  assert(state.plan, "missing plan");
  assert(state.patch, "missing patch");
  assert(state.gateResult, "missing gateResult");
  assert(state.gateResult.allowed, "gateResult did not allow");
  assert(typeof state.prNumber === "number", "missing prNumber");
  assert(state.commitSha, "missing commitSha");
  assert(state.astdocSha, "missing astdocSha");
  assert(state.canaryUrl, "missing canaryUrl");
  assert(state.mergedSha, "missing mergedSha");
  assert(state.postMergeSha, "missing postMergeSha");
  assert(state.review, "missing review");

  // 3. Phase timings cover every phase in order, with no time travel.
  const recorded = phases.filter((p) => state.phaseTimings[p]);
  assert(recorded.length === phases.length, "not all phases recorded");
  let previousEnd = new Date(state.startedAt).getTime();
  for (const phase of phases) {
    const timing = state.phaseTimings[phase]!;
    const start = new Date(timing.startedAt).getTime();
    const end = new Date(timing.endedAt).getTime();
    assert(start >= previousEnd, `phase ${phase} starts before previous phase ended`);
    assert(end >= start, `phase ${phase} ends before it starts`);
    assert(timing.durationMs >= 0, `phase ${phase} has negative duration`);
    previousEnd = end;
  }

  // 4. Telemetry has at least 20 events and each phase has at least 2 events.
  assert(result.events.length >= 20, `expected >= 20 events, got ${result.events.length}`);
  const counts: Partial<Record<Phase, number>> = {};
  for (const event of result.events) {
    const e = event as { phase: Phase };
    counts[e.phase] = (counts[e.phase] ?? 0) + 1;
  }
  for (const phase of phases) {
    assert((counts[phase] ?? 0) >= 2, `phase ${phase} has fewer than 2 events`);
  }

  // 5. Token usage is non-negative and cost is realistic.
  assert(result.totalUsage.totalTokens >= 0, "negative total tokens");
  assert(result.totalUsage.estimatedCostUsd >= 0, "negative estimated cost");

  // 6. PR and commit operations succeeded in the mock.
  const pr = await github.getPR(state.prNumber!);
  assert(pr?.state === "merged", "PR was not merged");
  assert(pr?.commits.some((c) => c.sha === state.commitSha), "commit SHA not in PR history");
  assert(pr?.mergedSha === state.mergedSha, "merged SHA mismatch");

  console.log("All validation checks passed.");
  console.log(`Run ID: ${state.runId}`);
  console.log(`Events: ${result.events.length}`);
  console.log(`Total tokens: ${result.totalUsage.totalTokens}`);
  console.log(`PR #${state.prNumber}, commit ${state.commitSha}, merged ${state.mergedSha}`);
}

validate().catch((err) => {
  console.error(err.message);
  process.exit(1);
});
