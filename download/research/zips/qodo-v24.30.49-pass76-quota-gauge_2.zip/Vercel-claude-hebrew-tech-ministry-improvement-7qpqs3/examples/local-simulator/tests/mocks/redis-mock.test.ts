import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createRedisMock } from "../../mocks/redis-mock.ts";

describe("RedisMock", () => {
  it("performs string operations", async () => {
    const redis = createRedisMock();
    await redis.set("key", "value");
    const value = await redis.get("key");
    assert.equal(value, "value");
    const removed = await redis.del("key");
    assert.equal(removed, 1);
    assert.equal(await redis.get("key"), null);
  });

  it("performs list operations", async () => {
    const redis = createRedisMock();
    const len = await redis.lpush("list", "a");
    assert.equal(len, 1);
    await redis.lpush("list", "b");
    const items = await redis.lrange("list", 0, -1);
    assert.deepEqual(items, ["b", "a"]);
  });

  it("performs hash operations", async () => {
    const redis = createRedisMock();
    const created = await redis.hset("hash", "field", "value");
    assert.equal(created, 1);
    assert.equal(await redis.hget("hash", "field"), "value");
  });

  it("increments counters", async () => {
    const redis = createRedisMock();
    assert.equal(await redis.incr("counter"), 1);
    assert.equal(await redis.incr("counter"), 2);
  });

  it("implements acquire/release locks", async () => {
    const redis = createRedisMock();
    assert.equal(await redis.acquire("lock"), true);
    assert.equal(await redis.acquire("lock"), false);
    assert.equal(await redis.release("lock"), true);
    assert.equal(await redis.acquire("lock"), true);
  });

  it("logs events and audit trail", async () => {
    const redis = createRedisMock();
    await redis.set("x", "1");
    await redis.get("x");
    const audit = await redis.getAuditLog();
    assert.equal(audit.length, 2);
    assert.equal(audit[0].op, "set");
  });
});
