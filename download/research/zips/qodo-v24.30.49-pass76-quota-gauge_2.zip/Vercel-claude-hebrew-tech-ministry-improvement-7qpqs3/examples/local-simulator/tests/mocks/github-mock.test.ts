import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createGitHubMock } from "../../mocks/github-mock.ts";

describe("GitHubMock", () => {
  it("creates a PR and commits files", async () => {
    const github = createGitHubMock();
    const { prNumber, branch, prUrl } = await github.createBranchAndPR("Test PR");
    assert.equal(prNumber, 1);
    assert.ok(branch.includes("test-pr"));
    assert.ok(prUrl.includes("1"));

    const commit = await github.commitViaGitDB(prNumber, [{ path: "src/index.ts", content: "console.log('ok');" }], "first commit");
    assert.ok(commit.sha.length === 40);
    assert.equal(commit.prNumber, prNumber);

    const file = await github.getFileAtRef("src/index.ts", branch);
    assert.equal(file, "console.log('ok');");
  });

  it("merges a PR", async () => {
    const github = createGitHubMock();
    const { prNumber } = await github.createBranchAndPR("Merge PR");
    await github.commitViaGitDB(prNumber, [{ path: "src/index.ts", content: "ok" }], "commit");
    const { mergedSha } = await github.mergePR(prNumber);
    assert.ok(mergedSha.length === 40);
    const pr = await github.getPR(prNumber);
    assert.equal(pr?.state, "merged");
  });

  it("records comments and check runs", async () => {
    const github = createGitHubMock();
    const { prNumber } = await github.createBranchAndPR("Checks");
    const commit = await github.commitViaGitDB(prNumber, [{ path: "x.ts", content: "" }], "c");
    const checkId = await github.createCheckRun(prNumber, "ci", commit.sha);
    await github.updateCheckRun(prNumber, checkId, "completed", "success", "ok");
    await github.postComment(prNumber, "LGTM");
    const pr = await github.getPR(prNumber);
    assert.equal(pr?.comments.length, 1);
    assert.equal(pr?.checkRuns[0]?.conclusion, "success");
  });
});
