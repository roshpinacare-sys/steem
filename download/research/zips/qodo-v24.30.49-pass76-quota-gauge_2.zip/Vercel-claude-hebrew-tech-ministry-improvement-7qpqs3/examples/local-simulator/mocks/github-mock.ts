import type {
  IVersionControl,
  CommitResult,
  PRRecord,
  CommitRecord,
  CheckRunRecord,
} from "../src/ports/IVersionControl.ts";
import { deterministicSha } from "../src/utils/hash.ts";

/**
 * In-memory GitHub mock implementing IVersionControl.
 *
 * Maintains a PR registry, commit history, mock file system, and check-run
 * state. All SHAs are deterministic from the inputs.
 */
export class GitHubMock implements IVersionControl {
  private prs: Map<number, PRRecord> = new Map();
  private nextPrNumber = 1;
  private nextCheckRunId = 1;
  private baseFiles: Record<string, string> = {
    "package.json": JSON.stringify({ name: "demo", version: "1.0.0" }),
    "src/index.ts": "export function main(): string { return 'hello'; }\n",
    "README.md": "# Demo\n",
  };
  private audit: Array<{ timestamp: string; op: string; args: unknown[] }> = [];

  private log(op: string, args: unknown[]): void {
    this.audit.push({ timestamp: new Date().toISOString(), op, args });
  }

  private shaSeed(...parts: (string | number)[]): string {
    return parts.join("|");
  }

  async createBranchAndPR(
    title: string,
    body = "",
  ): Promise<{ prNumber: number; branch: string; prUrl: string }> {
    this.log("createBranchAndPR", [title, body]);
    const prNumber = this.nextPrNumber++;
    const branch = `qodo/${prNumber}-${title.toLowerCase().replace(/\s+/g, "-")}`;
    const prUrl = `https://github.com/qodo/demo/pull/${prNumber}`;
    const pr: PRRecord = {
      number: prNumber,
      branch,
      title,
      state: "open",
      comments: body ? [body] : [],
      checkRuns: [],
      files: { ...this.baseFiles },
      commits: [],
    };
    this.prs.set(prNumber, pr);
    return { prNumber, branch, prUrl };
  }

  async commitViaGitDB(
    prNumber: number,
    files: Array<{ path: string; content: string }>,
    message: string,
  ): Promise<CommitResult> {
    this.log("commitViaGitDB", [prNumber, files, message]);
    const pr = this.prs.get(prNumber);
    if (!pr) {
      throw new Error(`PR #${prNumber} not found`);
    }
    const timestamp = new Date().toISOString();
    const sha = deterministicSha(this.shaSeed(prNumber, message, JSON.stringify(files)));
    for (const { path, content } of files) {
      pr.files[path] = content;
    }
    const commit: CommitRecord = { sha, message, files: Object.fromEntries(files.map((f) => [f.path, f.content])), timestamp };
    pr.commits.push(commit);
    return { sha, branch: pr.branch, prNumber, prUrl: `https://github.com/qodo/demo/pull/${prNumber}` };
  }

  async mergePR(prNumber: number): Promise<{ mergedSha: string }> {
    this.log("mergePR", [prNumber]);
    const pr = this.prs.get(prNumber);
    if (!pr) {
      throw new Error(`PR #${prNumber} not found`);
    }
    if (pr.commits.length === 0) {
      throw new Error(`PR #${prNumber} has no commits to merge`);
    }
    const lastCommit = pr.commits[pr.commits.length - 1];
    const mergedSha = deterministicSha(this.shaSeed("merge", prNumber, lastCommit.sha));
    pr.mergedSha = mergedSha;
    pr.state = "merged";
    this.baseFiles = { ...pr.files };
    return { mergedSha };
  }

  async getFileAtRef(path: string, ref: string): Promise<string | null> {
    this.log("getFileAtRef", [path, ref]);
    const pr = Array.from(this.prs.values()).find((p) => p.branch === ref || p.mergedSha === ref);
    if (pr) {
      return pr.files[path] ?? null;
    }
    return this.baseFiles[path] ?? null;
  }

  async postComment(prNumber: number, body: string): Promise<void> {
    this.log("postComment", [prNumber, body]);
    const pr = this.prs.get(prNumber);
    if (!pr) {
      throw new Error(`PR #${prNumber} not found`);
    }
    pr.comments.push(body);
  }

  async createCheckRun(prNumber: number, name: string, sha: string): Promise<number> {
    this.log("createCheckRun", [prNumber, name, sha]);
    const pr = this.prs.get(prNumber);
    if (!pr) {
      throw new Error(`PR #${prNumber} not found`);
    }
    const id = this.nextCheckRunId++;
    const run: CheckRunRecord = { id, name, sha, status: "queued" };
    pr.checkRuns.push(run);
    return id;
  }

  async updateCheckRun(
    prNumber: number,
    checkRunId: number,
    status: "in_progress" | "completed",
    conclusion?: string,
    summary?: string,
  ): Promise<void> {
    this.log("updateCheckRun", [prNumber, checkRunId, status, conclusion, summary]);
    const pr = this.prs.get(prNumber);
    if (!pr) {
      throw new Error(`PR #${prNumber} not found`);
    }
    const run = pr.checkRuns.find((r) => r.id === checkRunId);
    if (!run) {
      throw new Error(`Check run ${checkRunId} not found on PR #${prNumber}`);
    }
    run.status = status;
    if (conclusion !== undefined) run.conclusion = conclusion;
    if (summary !== undefined) run.summary = summary;
  }

  async getPR(prNumber: number): Promise<PRRecord | undefined> {
    this.log("getPR", [prNumber]);
    return this.prs.get(prNumber);
  }

  async getAuditLog(): Promise<Array<{ timestamp: string; op: string; args: unknown[] }>> {
    this.log("getAuditLog", []);
    return [...this.audit];
  }
}

export function createGitHubMock(): IVersionControl {
  return new GitHubMock();
}
