import type { IStateStore } from "../src/ports/IStateStore.ts";

interface LockRecord {
  holder: string;
  expiresAt: number;
}

/**
 * In-memory Redis mock implementing IStateStore.
 *
 * Keeps strings, hashes, lists, counters, locks, and an event stream entirely
 * in process memory. Records every operation in an audit log for replay.
 */
export class RedisMock implements IStateStore {
  private store: Map<string, string> = new Map();
  private lists: Map<string, string[]> = new Map();
  private hashes: Map<string, Map<string, string>> = new Map();
  private counters: Map<string, number> = new Map();
  private locks: Map<string, LockRecord> = new Map();
  private events: Map<string, unknown[]> = new Map();
  private audit: Array<{ timestamp: string; op: string; args: unknown[] }> = [];

  private log(op: string, args: unknown[]): void {
    this.audit.push({ timestamp: new Date().toISOString(), op, args });
  }

  private now(): number {
    return Date.now();
  }

  async lpush(key: string, value: string): Promise<number> {
    this.log("lpush", [key, value]);
    const list = this.lists.get(key) ?? [];
    list.unshift(value);
    this.lists.set(key, list);
    return list.length;
  }

  async lrange(key: string, start: number, stop: number): Promise<string[]> {
    this.log("lrange", [key, start, stop]);
    const list = this.lists.get(key) ?? [];
    // Redis LRANGE stop is inclusive; negative stop counts from the end.
    const end = stop < 0 ? list.length + stop + 1 : stop + 1;
    return list.slice(start, end);
  }

  async set(key: string, value: string): Promise<void> {
    this.log("set", [key, value]);
    this.store.set(key, value);
  }

  async get(key: string): Promise<string | null> {
    this.log("get", [key]);
    return this.store.get(key) ?? null;
  }

  async del(key: string): Promise<number> {
    this.log("del", [key]);
    let removed = 0;
    if (this.store.delete(key)) removed++;
    if (this.lists.delete(key)) removed++;
    if (this.hashes.delete(key)) removed++;
    this.counters.delete(key);
    return removed;
  }

  async exists(key: string): Promise<number> {
    this.log("exists", [key]);
    let count = 0;
    if (this.store.has(key)) count++;
    if (this.lists.has(key)) count++;
    if (this.hashes.has(key)) count++;
    if (this.counters.has(key)) count++;
    return count;
  }

  async incr(key: string): Promise<number> {
    this.log("incr", [key]);
    const next = (this.counters.get(key) ?? 0) + 1;
    this.counters.set(key, next);
    return next;
  }

  async hset(key: string, field: string, value: string): Promise<number> {
    this.log("hset", [key, field, value]);
    const hash = this.hashes.get(key) ?? new Map<string, string>();
    const isNew = !hash.has(field);
    hash.set(field, value);
    this.hashes.set(key, hash);
    return isNew ? 1 : 0;
  }

  async hget(key: string, field: string): Promise<string | null> {
    this.log("hget", [key, field]);
    return this.hashes.get(key)?.get(field) ?? null;
  }

  async acquire(lockId: string, ttlMs = 30000): Promise<boolean> {
    this.log("acquire", [lockId, ttlMs]);
    const existing = this.locks.get(lockId);
    if (existing && existing.expiresAt > this.now()) {
      return false;
    }
    this.locks.set(lockId, { holder: "qodo-agent", expiresAt: this.now() + ttlMs });
    return true;
  }

  async release(lockId: string): Promise<boolean> {
    this.log("release", [lockId]);
    return this.locks.delete(lockId);
  }

  async pushEvent(stream: string, event: unknown): Promise<void> {
    this.log("pushEvent", [stream, event]);
    const list = this.events.get(stream) ?? [];
    list.push(event);
    this.events.set(stream, list);
  }

  async getEvents(stream: string, limit = 1000): Promise<unknown[]> {
    const list = this.events.get(stream) ?? [];
    return list.slice(-limit);
  }

  async getState(): Promise<Record<string, unknown>> {
    const hashEntries: Record<string, Record<string, string>> = {};
    for (const [key, hash] of this.hashes) {
      hashEntries[key] = Object.fromEntries(hash);
    }
    return {
      strings: Object.fromEntries(this.store),
      lists: Object.fromEntries(
        Array.from(this.lists).map(([k, v]) => [k, [...v]]),
      ),
      hashes: hashEntries,
      counters: Object.fromEntries(this.counters),
      events: Object.fromEntries(
        Array.from(this.events).map(([k, v]) => [k, [...v]]),
      ),
    };
  }

  async getAuditLog(): Promise<Array<{ timestamp: string; op: string; args: unknown[] }>> {
    return [...this.audit];
  }
}

export function createRedisMock(): IStateStore {
  return new RedisMock();
}
