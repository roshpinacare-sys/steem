import type { AIRouter, TokenUsage, LLMCallRecord } from "../src/ports/AIRouter.ts";

/**
 * Deterministic in-memory LLM mock.
 *
 * Produces schema-valid JSON responses without network calls. Token counts
 * are derived from prompt length using a fixed ratio so the same prompt
 * always yields the same usage.
 */
export class LLMMock implements AIRouter {
  private calls: LLMCallRecord[] = [];
  private totalUsage: TokenUsage = {
    promptTokens: 0,
    completionTokens: 0,
    totalTokens: 0,
    estimatedCostUsd: 0,
  };

  private now(): string {
    return new Date().toISOString();
  }

  private tokenUsage(prompt: string, responseJson: string): TokenUsage {
    const promptTokens = Math.ceil(prompt.length / 4);
    const completionTokens = Math.ceil(responseJson.length / 4);
    const totalTokens = promptTokens + completionTokens;
    // Free-tier estimate: $0.0001 per 1k tokens.
    const estimatedCostUsd = Math.round((totalTokens / 1000) * 0.0001 * 1e6) / 1e6;
    return { promptTokens, completionTokens, totalTokens, estimatedCostUsd };
  }

  private record(role: "architect" | "coder" | "reviewer" | "meta", prompt: string, response: unknown, usage: TokenUsage): void {
    this.calls.push({ timestamp: this.now(), role, query: prompt, response, usage });
    this.totalUsage.promptTokens += usage.promptTokens;
    this.totalUsage.completionTokens += usage.completionTokens;
    this.totalUsage.totalTokens += usage.totalTokens;
    this.totalUsage.estimatedCostUsd += usage.estimatedCostUsd;
  }

  async callArchitect(prompt: string): Promise<{ plan: unknown; usage: TokenUsage }> {
    const objective = prompt.split("Mission: ").pop() || "unknown";
    const plan = {
      objective,
      steps: [
        {
          id: "step-1",
          description: "Analyze requirements and produce implementation plan",
          files: ["src/index.ts"],
          prefetch: ["src/index.ts", "package.json"],
        },
        {
          id: "step-2",
          description: "Implement the requested change",
          files: ["src/index.ts"],
        },
      ],
      prefetch: ["src/index.ts", "package.json"],
      confidence: 0.92,
      risk: "low",
    };
    const usage = this.tokenUsage(prompt, JSON.stringify(plan));
    this.record("architect", prompt, plan, usage);
    return { plan, usage };
  }

  async callCoder(prompt: string): Promise<{ patch: unknown; usage: TokenUsage }> {
    const patch = {
      diff: `--- a/src/index.ts\n+++ b/src/index.ts\n@@ -1 +1 @@\n-export function main(): string { return 'hello'; }\n+export function main(): string { return 'hello, qodo'; }`,
      files: [
        {
          path: "src/index.ts",
          content: "export function main(): string { return 'hello, qodo'; }\n",
        },
      ],
      tokensUsed: 120,
      finishReason: "stop",
    };
    const usage = this.tokenUsage(prompt, JSON.stringify(patch));
    this.record("coder", prompt, patch, usage);
    return { patch, usage };
  }

  async callReviewer(prompt: string): Promise<{ review: unknown; usage: TokenUsage }> {
    const review = {
      decision: "approve" as const,
      score: 92,
      reasoning: "Patch is minimal, focused, and aligns with the objective. No breaking changes detected.",
      issues: [],
      suggestions: ["Consider adding a unit test for the updated greeting."],
      annotations: [],
    };
    const usage = this.tokenUsage(prompt, JSON.stringify(review));
    this.record("reviewer", prompt, review, usage);
    return { review, usage };
  }

  async callMetaAgent(prompt: string): Promise<{ decision: unknown; usage: TokenUsage }> {
    const decision = {
      action: "proceed",
      confidence: 0.95,
      reasoning: "All gates passed and telemetry is healthy.",
    };
    const usage = this.tokenUsage(prompt, JSON.stringify(decision));
    this.record("meta", prompt, decision, usage);
    return { decision, usage };
  }

  async getCalls(): Promise<LLMCallRecord[]> {
    return [...this.calls];
  }

  async getTotalUsage(): Promise<TokenUsage> {
    return { ...this.totalUsage };
  }
}

export function createLLMMock(): AIRouter {
  return new LLMMock();
}
